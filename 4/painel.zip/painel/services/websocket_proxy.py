from utils.cmd import run_remote

BIN_WS  = "/usr/local/bin/websocketd"
BIN_SOC = "/usr/bin/socat"

def install(server):
    # websocketd
    run_remote(server,
        f"command -v {BIN_WS} || "
        "curl -sL https://github.com/joewalnes/websocketd/releases/download/v0.4.1/"
        "websocketd-0.4.1-linux_amd64.tar.gz | tar xz -C /usr/local/bin --strip-components=1 websocketd-0.4.1-linux_amd64/websocketd")
    # socat
    run_remote(server, f"apt -y install socat")

def _screen(port):      # nome da sessão screen
    return f"ws{port}"

def start(server, port):
    install(server)
    # Se existir sessão antiga, mata antes
    run_remote(server, f"screen -S {_screen(port)} -X quit || true")
    # websocketd + socat:  websocketd --port PORT --staticdir=/dev/null \
    #                      /usr/bin/socat - TCP4:127.0.0.1:PORT
    cmd = (f"screen -dmS {_screen(port)} "
           f"{BIN_WS} --port={port} "
           f"{BIN_SOC} - TCP4:127.0.0.1:{port}")
    run_remote(server, cmd)

def stop(server, port):
    run_remote(server, f"screen -S {_screen(port)} -X quit || true")

def status(server, port):
    out = run_remote(server, "screen -ls", capture=True)
    return "active" if _screen(port) in out else "inactive"