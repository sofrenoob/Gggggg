from utils.cmd import run_remote
BIN = "/usr/local/bin/sdns-server"
DEF_PUBKEY = "/etc/slowdns.pub"
DEF_PRIVKEY = "/etc/slowdns.key"

def install(server):
    run_remote(server,
       "apt -y install screen wget git make gcc libsodium-dev && "
       "test -f {bin} || (git clone https://github.com/phreaker56/slowdns.git /tmp/slowdns && "
       "cd /tmp/slowdns/server && make && cp sdns-server {bin})".format(bin=BIN))
    # gera chave se não existir
    run_remote(server,
        f"test -f {DEF_PUBKEY} || {BIN} -gen-key -priv {DEF_PRIVKEY} -pub {DEF_PUBKEY}")

def _screen(port): return f"slowdns{port}"

def start(server, port):
    # “porta” aqui é o porto TCP de controle; UDP/53 continua necessário
    install(server)
    run_remote(server,
        f"screen -dmS {_screen(port)} {BIN} -udp :{port} -priv {DEF_PRIVKEY} -pub {DEF_PUBKEY}")

def stop(server, port):
    run_remote(server, f"screen -S {_screen(port)} -X quit || true")

def status(server, port):
    out = run_remote(server, "screen -ls", capture=True)
    return "active" if _screen(port) in out else "inactive"