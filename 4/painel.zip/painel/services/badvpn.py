from utils.cmd import run_remote
BIN = "/usr/local/bin/badvpn-udpgw"
def install(server):
    run_remote(server,
      f"command -v {BIN} || (apt -y install cmake make g++ screen git && "
      "git clone https://github.com/ambrop72/badvpn.git /tmp/badvpn && "
      "cd /tmp/badvpn && cmake -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1 . && "
      "make -j4 && cp udpgw/badvpn-udpgw " + BIN + ")")

def _screen(port): return f"badvpn{port}"

def start(server, port):
    install(server)
    run_remote(server, f"screen -dmS {_screen(port)} {BIN} --listen-addr 0.0.0.0:{port}")

def stop(server, port):
    run_remote(server, f"screen -S {_screen(port)} -X quit || true")

def status(server, port):
    out = run_remote(server, "screen -ls", capture=True)
    return "active" if _screen(port) in out else "inactive"