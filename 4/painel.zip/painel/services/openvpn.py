from utils.cmd import run_remote, run_local
def install(server):
    run_remote(server, "apt -y install openvpn")
def start(server, port):
    run_remote(server, f"systemctl start openvpn@{port}")
def stop(server, port):
    run_remote(server, f"systemctl stop openvpn@{port}")
def status(server, port):
    return run_remote(server, f"systemctl is-active openvpn@{port}", capture=True)