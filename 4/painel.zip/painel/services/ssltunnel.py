from utils.cmd import run_remote

BIN = "/usr/bin/stunnel"
CONF_DIR = "/etc/stunnel/panel"
def install(server):
    run_remote(server, f"apt -y install stunnel4 && mkdir -p {CONF_DIR}")

def _conf(port): return f"{CONF_DIR}/s{port}.conf"
def _screen(port): return f"ssl{port}"

def start(server, port):
    install(server)
    run_remote(server,
        "test -f /etc/stunnel/stunnel.pem || "
        "openssl req -new -x509 -days 3650 -nodes "
        "-subj \"/CN=localhost\" -out /etc/stunnel/stunnel.pem -keyout /etc/stunnel/stunnel.pem")
    run_remote(server, f"""bash -c 'cat > {_conf(port)} <<EOF
cert = /etc/stunnel/stunnel.pem
foreground = yes
accept = {port}
connect = 127.0.0.1:{port}
EOF'""")
    run_remote(server, f"screen -dmS {_screen(port)} {BIN} {_conf(port)}")

def stop(server, port):
    run_remote(server, f"screen -S {_screen(port)} -X quit || true")
    run_remote(server, f"rm -f {_conf(port)}")

def status(server, port):
    out = run_remote(server, "screen -ls", capture=True)
    return "active" if _screen(port) in out else "inactive"