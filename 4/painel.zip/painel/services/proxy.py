from utils.cmd import run_remote

def install(server):
    run_remote(server, "apt -y install squid")

def _conf(port): return f"/etc/squid/squid-{port}.conf"
def _service(port): return f"squid@{port}"

def start(server, port):
    install(server)
    # cria config mínima
    run_remote(server, f"""bash -c 'cat > {_conf(port)} <<EOF
http_port {port}
visible_hostname proxy{port}
acl all src 0.0.0.0/0
http_access allow all
cache deny all
EOF'""")
    # cria unit template se ainda não existir
    run_remote(server, """bash -c 'test -f /etc/systemd/system/squid@.service || cat > /etc/systemd/system/squid@.service <<UNIT
[Unit]
Description=Squid HTTP proxy instance on %%i
After=network.target

[Service]
ExecStart=/usr/sbin/squid -f /etc/squid/squid-%%i.conf -N
ExecReload=/bin/kill -HUP $MAINPID
Restart=always

[Install]
WantedBy=multi-user.target
UNIT'""")
    run_remote(server, "systemctl daemon-reload")
    run_remote(server, f"systemctl enable --now {_service(port)}")

def stop(server, port):
    run_remote(server, f"systemctl disable --now {_service(port)} || true")
    run_remote(server, f"rm -f {_conf(port)}")

def status(server, port):
    return run_remote(server, f"systemctl is-active {_service(port)}", capture=True)