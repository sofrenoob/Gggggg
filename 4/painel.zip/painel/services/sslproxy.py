from utils.cmd import run_remote

STUNNEL_DIR = "/etc/stunnel"
SERVICE = "stunnel4"

def install(server):
    run_remote(server, "apt -y install stunnel4")
    # Garante que stunnel esteja habilitado
    run_remote(server, "sed -i 's/ENABLED=.*/ENABLED=1/' /etc/default/stunnel4")

def _conf_name(port): return f"{STUNNEL_DIR}/p{port}.conf"

def start(server, port):
    install(server)
    # cria certificado self-signed se não existir
    run_remote(server,
        "test -f /etc/stunnel/stunnel.pem || "
        "openssl req -new -x509 -days 3650 -nodes "
        "-subj '/CN=localhost' -out /etc/stunnel/stunnel.pem -keyout /etc/stunnel/stunnel.pem")
    # cria config dedicada
    run_remote(server, f"""bash -c 'cat > {_conf_name(port)} <<EOF
cert = /etc/stunnel/stunnel.pem
accept = {port}
connect = 127.0.0.1:{port}
EOF'""")
    run_remote(server, f"systemctl restart {SERVICE}")

def stop(server, port):
    run_remote(server, f"rm -f {_conf_name(port)}")
    run_remote(server, f"systemctl restart {SERVICE}")

def status(server, port):
    output = run_remote(server, f"grep -q '^accept = {port}$' {_conf_name(port)} && echo active || echo inactive",
                        capture=True)
    return output.strip()