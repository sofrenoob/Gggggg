from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime
from models import db, SSHUser
from utils.cmd import run_remote

sched = BackgroundScheduler()

@sched.scheduled_job('interval', minutes=10)
def expire_users():
    now = datetime.utcnow()
    for usr in SSHUser.query.filter(SSHUser.expires_at < now).all():
        try:
            run_remote(usr.server, f"userdel -f {usr.username}")
        except Exception as e:
            print(e)
        db.session.delete(usr)
    db.session.commit()

def start_scheduler(app):
    sched.init_app(app)
    sched.start()