#!/usr/bin/env python3
"""
Mini-agente que devolve métricas em JSON via HTTPS ou executa comandos
recebidos do master (não obrigatório para um único servidor).
"""
import argparse, psutil, json, flask, subprocess, os

app = flask.Flask(__name__)
KEY=""
def auth(req):
    return req.headers.get('X-Token')==KEY

@app.route('/metrics')
def metrics():
    if not auth(flask.request): return '',403
    m=dict(cpu=psutil.cpu_percent(),
           ram=psutil.virtual_memory().percent,
           users=len(psutil.users()))
    return flask.jsonify(m)

@app.route('/cmd', methods=['POST'])
def cmd():
    if not auth(flask.request): return '',403
    out=subprocess.check_output(flask.request.json['cmd'], shell=True, text=True)
    return flask.jsonify(out=out)

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument('--key', required=True)
    ap.add_argument('--port', default=5005, type=int)
    args=ap.parse_args(); KEY=args.key
    app.run('0.0.0.0', args.port)