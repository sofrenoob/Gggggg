from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, login_required, login_user, logout_user, current_user
from config import Config
from models import db, AdminUser, Server, Service
import psutil, importlib
from utils import ufw
from sched import start_scheduler

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)

    login = LoginManager(app)
    login.login_view = 'login'

    @login.user_loader
    def load(uid): return AdminUser.query.get(int(uid))

    @app.before_first_request
    def _init():
        start_scheduler(app)

    # ---------- auth ----------
    @app.route('/login', methods=['GET','POST'])
    def login():
        if request.method == 'POST':
            u = AdminUser.query.filter_by(username=request.form['user']).first()
            if u and u.check_pwd(request.form['pwd']):
                login_user(u)
                return redirect(url_for('index'))
            flash('Credenciais inválidas')
        return render_template('login.html')

    @app.route('/logout'); @login_required
    def logout(): logout_user(); return redirect(url_for('login'))

    # ---------- dashboard ----------
    @app.route('/'); @login_required
    def index():
        sysinfo = dict(cpu=psutil.cpu_percent(interval=0.3),
                       ram=psutil.virtual_memory().percent,
                       mem_free=psutil.virtual_memory().available//(1024**2),
                       users=len(psutil.users()))
        return render_template('index.html',
                               services=Service.query.all(),
                               sys=sysinfo)

    # ---------- toggle service ----------
    @app.post('/service/toggle')
    @login_required
    def toggle():
        svc = Service.query.get(int(request.form['id']))
        plugin = importlib.import_module(f"services.{svc.name}")
        try:
            (plugin.start if not svc.active else plugin.stop)(svc.server, svc.port)
            svc.active = not svc.active; db.session.commit()
        except Exception as e:
            flash(str(e))
        return redirect(url_for('index'))

    # ---------- firewall ----------
    @app.post('/port')
    @login_required
    def port():
        port = request.form['port']; proto=request.form['proto']
        if request.form['action']=='open': ufw.allow(port, proto)
        else: ufw.deny(port, proto)
        return ('',204)

    return app

if __name__ == '__main__':
    create_app().run(debug=True, host='0.0.0.0', port=8080)