#!/usr/bin/env bash
set -e
sudo apt update
sudo apt -y install python3 python3-venv python3-pip ufw git build-essential
TARGET=/opt/serverpanel
sudo mkdir -p $TARGET && sudo chown $USER:$USER $TARGET
cp -R . $TARGET
cd $TARGET
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

python - <<'PY'
from app import create_app
from models import db, AdminUser
app=create_app()
with app.app_context():
    db.create_all()
    import getpass,sys
    user=input("Usuário admin: "); pwd=getpass.getpass("Senha: ")
    AdminUser.create(user,pwd)
PY

sudo tee /etc/systemd/system/panel.service >/dev/null <<EOF
[Unit]
Description=Painel Servidor
After=network.target
[Service]
WorkingDirectory=$TARGET
ExecStart=$TARGET/venv/bin/gunicorn -b 0.0.0.0:8080 app:create_app()
Restart=always
[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now panel
echo "Pronto! acesse http://$(hostname -I | awk '{print $1}'):8080"