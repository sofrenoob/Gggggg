from utils.cmd import run_local
def allow(port, proto):  run_local(f"sudo ufw allow {port}/{proto}")
def deny(port, proto):   run_local(f"sudo ufw delete allow {port}/{proto}")