import subprocess, paramiko, tempfile, os

def run_local(cmd, capture=False):
    res = subprocess.run(cmd, shell=True, text=True,
                         capture_output=capture, check=False)
    if res.returncode != 0:
        raise RuntimeError(res.stderr)
    return res.stdout.strip() if capture else None

def run_remote(server, cmd, capture=False):
    keyfile = tempfile.NamedTemporaryFile(delete=False)
    keyfile.write(server.ssh_key.encode()); keyfile.close()
    k = paramiko.RSAKey.from_private_key_file(keyfile.name)
    ssh = paramiko.SSHClient(); ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(server.host, port=server.ssh_port, username='root', pkey=k)
    stdin, stdout, stderr = ssh.exec_command(cmd)
    exit_code = stdout.channel.recv_exit_status()
    os.unlink(keyfile.name)
    if exit_code != 0:
        raise RuntimeError(stderr.read().decode())
    return stdout.read().decode().strip() if capture else None