from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from datetime import datetime, timedelta
db = SQLAlchemy()
bcrypt = Bcrypt()

class AdminUser(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(40), unique=True, nullable=False)
    passwd_hash = db.Column(db.String(128), nullable=False)

    def check_pwd(self, pwd):
        return bcrypt.check_password_hash(self.passwd_hash, pwd)

    @classmethod
    def create(cls, user, pwd):
        obj = cls(username=user,
                  passwd_hash=bcrypt.generate_password_hash(pwd))
        db.session.add(obj); db.session.commit()

class Server(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(60))
    host = db.Column(db.String(100))
    ssh_port = db.Column(db.Integer, default=22)
    ssh_key = db.Column(db.Text)
    last_seen = db.Column(db.DateTime)

class Service(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    server_id = db.Column(db.Integer, db.ForeignKey('server.id'))
    name = db.Column(db.String(30))
    port = db.Column(db.Integer)
    active = db.Column(db.Boolean, default=False)
    server = db.relationship('Server')

class SSHUser(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    server_id = db.Column(db.Integer, db.ForeignKey('server.id'))
    username = db.Column(db.String(40))
    password = db.Column(db.String(40))
    limit = db.Column(db.Integer)
    expires_at = db.Column(db.DateTime)
    hourly_test = db.Column(db.Integer, default=0)
    server = db.relationship('Server')