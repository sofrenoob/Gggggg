import os
class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'troque-me')
    SQLALCHEMY_DATABASE_URI = 'sqlite:///panel.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False