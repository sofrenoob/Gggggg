// static/js/script.js
console.log("App Store carregada!");