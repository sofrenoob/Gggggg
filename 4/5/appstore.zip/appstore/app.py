from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash, session
from flask_sqlalchemy import SQLAlchemy
import os
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'sua_chave_secreta_aqui'  # Mude isso para algo seguro
app.config['UPLOAD_FOLDER_APKS'] = 'apks'
app.config['UPLOAD_FOLDER_ICONS'] = 'static/icons'
db = SQLAlchemy(app)

# Modelo para Apps
class AppEntry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(500), nullable=False)
    apk_filename = db.Column(db.String(100), nullable=False)
    icon_filename = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(50), nullable=False)

# Modelo para Administradores
class Admin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

# Crie o banco de dados (execute uma vez)
with app.app_context():
    db.create_all()
    # Crie um admin padrão se não existir
    if not Admin.query.first():
        admin = Admin(username='admin', password=generate_password_hash('admin123'))
        db.session.add(admin)
        db.session.commit()

# Função para verificar login
def login_required(f):
    def wrap(*args, **kwargs):
        if 'logged_in' not in session:
            flash('Faça login para acessar esta página.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    wrap.__name__ = f.__name__
    return wrap

# Rota principal (página pública)
@app.route('/')
def index():
    apps = AppEntry.query.all()
    categories = set(app.category for app in apps)
    return render_template('index.html', apps=apps, categories=categories)

# Rota para download dos APKs
@app.route('/download/<filename>')
def download_apk(filename):
    return send_from_directory('apks', filename, as_attachment=True)

# Rota de login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        admin = Admin.query.filter_by(username=username).first()
        if admin and check_password_hash(admin.password, password):
            session['logged_in'] = True
            session['username'] = username
            flash('Login bem-sucedido!', 'success')
            return redirect(url_for('admin'))
        flash('Usuário ou senha inválidos.', 'error')
    return render_template('login.html')

# Rota de logout
@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    session.pop('username', None)
    flash('Você saiu com sucesso.', 'success')
    return redirect(url_for('index'))

# Rota do painel admin
@app.route('/admin')
@login_required
def admin():
    apps = AppEntry.query.all()
    return render_template('admin.html', apps=apps)

# Rota para adicionar/editar apps
@app.route('/admin/app', methods=['GET', 'POST'])
@app.route('/admin/app/<int:app_id>', methods=['GET', 'POST'])
@login_required
def manage_app(app_id=None):
    app_entry = AppEntry.query.get(app_id) if app_id else None
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        category = request.form['category']
        
        # Upload do APK
        apk_file = request.files['apk']
        apk_filename = secure_filename(apk_file.filename)
        apk_file.save(os.path.join(app.config['UPLOAD_FOLDER_APKS'], apk_filename))
        
        # Upload do ícone
        icon_file = request.files['icon']
        icon_filename = secure_filename(icon_file.filename)
        icon_file.save(os.path.join(app.config['UPLOAD_FOLDER_ICONS'], icon_filename))
        
        if app_entry:
            app_entry.name = name
            app_entry.description = description
            app_entry.apk_filename = apk_filename
            app_entry.icon_filename = icon_filename
            app_entry.category = category
        else:
            new_app = AppEntry(
                name=name,
                description=description,
                apk_filename=apk_filename,
                icon_filename=icon_filename,
                category=category
            )
            db.session.add(new_app)
        db.session.commit()
        flash('App salvo com sucesso!', 'success')
        return redirect(url_for('admin'))
    return render_template('manage_app.html', app=app_entry)

# Rota para excluir apps
@app.route('/admin/app/delete/<int:app_id>')
@login_required
def delete_app(app_id):
    app_entry = AppEntry.query.get(app_id)
    if app_entry:
        db.session.delete(app_entry)
        db.session.commit()
        flash('App excluído com sucesso!', 'success')
    return redirect(url_for('admin'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)