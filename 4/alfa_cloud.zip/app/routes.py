from flask import render_template, request, redirect, url_for, flash, session
from . import app, db
from .models import User, Proxy, Config, ConnectionLog
from datetime import datetime
import subprocess
import hashlib
import os

# Função auxiliar para verificar se o admin está logado
def is_admin_logged_in():
    return session.get('admin', False)

# Página inicial
@app.route('/')
def index():
    # Carrega banners e número do WhatsApp
    banners = Config.query.filter(Config.key.like('banner%')).all()
    whatsapp = Config.query.filter_by(key='whatsapp').first()
    return render_template('index.html', banners=banners, whatsapp=whatsapp)

# Login do administrador
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = hashlib.sha256(request.form['password'].encode()).hexdigest()
        stored_password = hashlib.sha256(app.config['ADMIN_PASSWORD'].encode()).hexdigest()
        if username == app.config['ADMIN_USERNAME'] and password == stored_password:
            session['admin'] = True
            return redirect(url_for('admin_dashboard'))
        flash('Credenciais inválidas', 'error')
    return render_template('admin_login.html')

# Logout do administrador
@app.route('/admin/logout')
def admin_logout():
    session.pop('admin', None)
    return redirect(url_for('index'))

# Painel do administrador
@app.route('/admin/dashboard')
def admin_dashboard():
    if not is_admin_logged_in():
        return redirect(url_for('admin_login'))
    # Estatísticas básicas
    user_count = User.query.count()
    proxy_count = Proxy.query.count()
    active_connections = ConnectionLog.query.filter_by(status='active').count()
    return render_template('admin_dashboard.html', 
                         user_count=user_count, 
                         proxy_count=proxy_count, 
                         active_connections=active_connections)

# Gerenciamento de usuários
@app.route('/admin/users', methods=['GET', 'POST'])
def users():
    if not is_admin_logged_in():
        return redirect(url_for('admin_login'))

    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'create':
            username = request.form['username']
            password = request.form['password']
            expiration = datetime.strptime(request.form['expiration'], '%Y-%m-%d')
            connection_limit = int(request.form['connection_limit'])
            
            # Verifica se o usuário já existe
            if User.query.filter_by(username=username).first():
                flash('Usuário já existe', 'error')
            else:
                user = User(
                    username=username,
                    password=password,  # Em produção, usar hash seguro
                    expiration=expiration,
                    connection_limit=connection_limit
                )
                db.session.add(user)
                db.session.commit()
                # Executa script para criar usuário SSH
                subprocess.run(['scripts/ssh_users.sh', 'create', username, password, str(connection_limit)])
                flash('Usuário criado com sucesso', 'success')

        elif action == 'edit':
            user_id = request.form['user_id']
            user = User.query.get(user_id)
            if user:
                user.password = request.form['password']
                user.expiration = datetime.strptime(request.form['expiration'], '%Y-%m-%d')
                user.connection_limit = int(request.form['connection_limit'])
                db.session.commit()
                subprocess.run(['scripts/ssh_users.sh', 'edit', user.username, request.form['password'], str(user.connection_limit)])
                flash('Usuário atualizado', 'success')

        elif action == 'delete':
            user_id = request.form['user_id']
            user = User.query.get(user_id)
            if user:
                subprocess.run(['scripts/ssh_users.sh', 'delete', user.username])
                db.session.delete(user)
                db.session.commit()
                flash('Usuário removido', 'success')

        elif action == 'backup':
            subprocess.run(['scripts/ssh_users.sh', 'backup'])
            flash('Backup realizado', 'success')

        elif action == 'restore':
            subprocess.run(['scripts/ssh_users.sh', 'restore'])
            flash('Backup restaurado', 'success')

    users = User.query.all()
    return render_template('users.html', users=users)

# Gerenciamento de conexões
@app.route('/admin/connections', methods=['GET', 'POST'])
def connections():
    if not is_admin_logged_in():
        return redirect(url_for('admin_login'))

    services = ['websocket', 'socks', 'ssltunnel', 'sslproxy', 'badvpn', 'udpgw', 'slowdns', 'direct']
    
    if request.method == 'POST':
        service = request.form['service']
        action = request.form['action']
        port = request.form.get('port', '')

        # Executa o script de gerenciamento de conexões
        result = subprocess.run(['scripts/connections.sh', action, service, port], capture_output=True, text=True)
        if result.returncode == 0:
            flash(f'{service} {action} com sucesso', 'success')
        else:
            flash(f'Erro ao {action} {service}: {result.stderr}', 'error')

        # Log da conexão
        if action in ['start', 'stop']:
            log = ConnectionLog(
                service=service,
                port=port,
                status='active' if action == 'start' else 'closed',
                ended_at=datetime.utcnow() if action == 'stop' else None
            )
            db.session.add(log)
            db.session.commit()

    # Obtém status dos serviços
    status = {}
    for service in services:
        try:
            output = subprocess.check_output(['scripts/connections.sh', 'status', service], text=True)
            status[service] = output.strip()
        except:
            status[service] = 'Desativado'

    return render_template('connections.html', services=services, status=status)

# Gerenciamento de proxies
@app.route('/admin/proxies', methods=['GET', 'POST'])
def proxies():
    if not is_admin_logged_in():
        return redirect(url_for('admin_login'))

    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'add':
            ip = request.form['ip']
            port = request.form['port']
            protocol = request.form['protocol']
            
            # Verifica se o proxy já existe
            if Proxy.query.filter_by(ip=ip, port=port, protocol=protocol).first():
                flash('Proxy já existe', 'error')
            else:
                proxy = Proxy(ip=ip, port=int(port), protocol=protocol)
                db.session.add(proxy)
                db.session.commit()
                # Executa script para adicionar proxy
                subprocess.run(['python', 'scripts/proxy_manager.py', 'add', ip, port, protocol])
                flash('Proxy adicionado', 'success')

        elif action == 'check':
            proxy_id = request.form['proxy_id']
            proxy = Proxy.query.get(proxy_id)
            if proxy:
                result = subprocess.run(['python', 'scripts/proxy_manager.py', 'check', proxy.ip, str(proxy.port), proxy.protocol], capture_output=True, text=True)
                proxy.last_checked = datetime.utcnow()
                proxy.status = 'active' if 'active' in result.stdout.lower() else 'inactive'
                db.session.commit()
                flash(f'Proxy {proxy.ip}:{proxy.port} verificado: {proxy.status}', 'success')

        elif action == 'delete':
            proxy_id = request.form['proxy_id']
            proxy = Proxy.query.get(proxy_id)
            if proxy:
                db.session.delete(proxy)
                db.session.commit()
                flash('Proxy removido', 'success')

    proxies = Proxy.query.all()
    return render_template('proxies.html', proxies=proxies)

# Gerenciamento de configurações (banners, WhatsApp, etc.)
@app.route('/admin/config', methods=['GET', 'POST'])
def config():
    if not is_admin_logged_in():
        return redirect(url_for('admin_login'))

    if request.method == 'POST':
        key = request.form['key']
        value = request.form['value']
        
        config_entry = Config.query.filter_by(key=key).first()
        if config_entry:
            config_entry.value = value
        else:
            config_entry = Config(key=key, value=value)
            db.session.add(config_entry)
        db.session.commit()
        flash('Configuração atualizada', 'success')

    configs = Config.query.all()
    return render_template('config.html', configs=configs)