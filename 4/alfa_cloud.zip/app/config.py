import os

# Chave secreta para sessões (gerada aleatoriamente)
SECRET_KEY = os.urandom(24)

# Caminho para o banco de dados SQLite
SQLALCHEMY_DATABASE_URI = 'sqlite:///../db/alfa_cloud.db'

# Desativa notificações de modificações no banco de dados (economiza recursos)
SQLALCHEMY_TRACK_MODIFICATIONS = False

# Configurações adicionais do sistema
ADMIN_USERNAME = 'admin'  # Usuário padrão do admin (alterar em produção)
ADMIN_PASSWORD = 'admin123'  # Senha padrão do admin (alterar em produção)