from flask import Flask
from flask_sqlalchemy import SQLAlchemy
import os

# Inicializa o Flask
app = Flask(__name__)

# Carrega as configurações do arquivo config.py
app.config.from_pyfile('config.py')

# Inicializa o banco de dados
db = SQLAlchemy(app)

# Importa as rotas após a inicialização do app
from . import routes

# Cria as tabelas do banco de dados se não existirem
with app.app_context():
    db.create_all()