from . import db
from datetime import datetime

# Modelo para usuários SSH/VPN
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    expiration = db.Column(db.DateTime, nullable=False)
    connection_limit = db.Column(db.Integer, default=1)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='active')  # active, suspended, expired

# Modelo para proxies
class Proxy(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ip = db.Column(db.String(50), nullable=False)
    port = db.Column(db.Integer, nullable=False)
    protocol = db.Column(db.String(20), nullable=False)  # Ex.: websocket, socks
    status = db.Column(db.String(20), default='active')  # active, inactive
    last_checked = db.Column(db.DateTime, default=datetime.utcnow)
    data_transferred = db.Column(db.Float, default=0.0)  # MB transferidos

# Modelo para configurações do sistema (banners, WhatsApp, etc.)
class Config(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(50), unique=True, nullable=False)  # Ex.: banner1, whatsapp
    value = db.Column(db.String(500), nullable=False)  # URL da imagem, número do WhatsApp, etc.

# Modelo para logs de conexões
class ConnectionLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    proxy_id = db.Column(db.Integer, db.ForeignKey('proxy.id'), nullable=True)
    service = db.Column(db.String(20), nullable=False)  # Ex.: websocket, socks
    port = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(20), default='active')  # active, closed
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    ended_at = db.Column(db.DateTime, nullable=True)