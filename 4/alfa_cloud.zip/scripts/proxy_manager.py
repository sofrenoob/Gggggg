#!/usr/bin/env python3

import sys
import requests
import socket
import time
from datetime import datetime
import sqlite3
import os

DB_PATH = "/alfa_cloud/db/alfa_cloud.db"

def add_proxy(ip, port, protocol):
    """Adiciona um proxy ao sistema e verifica sua conectividade."""
    print(f"Adicionando proxy {ip}:{port} ({protocol})")
    try:
        # Verifica se o proxy está ativo
        proxies = {protocol: f"{protocol}://{ip}:{port}"}
        response = requests.get("http://example.com", proxies=proxies, timeout=5)
        status = "active" if response.status_code == 200 else "inactive"
        print(f"Proxy {status}: {response.status_code}")

        # Atualiza o banco de dados
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE proxy SET status = ?, last_checked = ? 
                WHERE ip = ? AND port = ? AND protocol = ?
            """, (status, datetime.utcnow().isoformat(), ip, port, protocol))
            conn.commit()
    except Exception as e:
        print(f"Erro ao verificar proxy: {e}")
        status = "inactive"
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE proxy SET status = ?, last_checked = ? 
                WHERE ip = ? AND port = ? AND protocol = ?
            """, (status, datetime.utcnow().isoformat(), ip, port, protocol))
            conn.commit()

def check_proxy(ip, port, protocol):
    """Verifica o status e portas do proxy."""
    try:
        # Testa conectividade básica
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        result = sock.connect_ex((ip, int(port)))
        sock.close()
        status = "active" if result == 0 else "inactive"

        # Verifica transferência de dados (simulada)
        data_transferred = 0.0  # Substituir por monitoramento real (ex.: iptables)
        
        print(f"Proxy {ip}:{port} ({protocol}) - Status: {status}, Dados: {data_transferred} MB")
        
        # Atualiza o banco de dados
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE proxy SET status = ?, last_checked = ?, data_transferred = ? 
                WHERE ip = ? AND port = ? AND protocol = ?
            """, (status, datetime.utcnow().isoformat(), data_transferred, ip, port, protocol))
            conn.commit()
        
        return {"status": status, "port": port, "data_transferred": data_transferred}
    except Exception as e:
        print(f"Erro ao verificar proxy: {e}")
        return {"status": "inactive", "port": port, "data_transferred": 0.0}

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python3 proxy_manager.py {add|check} ip port protocol")
        sys.exit(1)

    action = sys.argv[1]
    ip = sys.argv[2] if len(sys.argv) > 2 else ""
    port = sys.argv[3] if len(sys.argv) > 3 else ""
    protocol = sys.argv[4] if len(sys.argv) > 4 else ""

    if action == "add":
        add_proxy(ip, port, protocol)
    elif action == "check":
        result = check_proxy(ip, port, protocol)
        print(result)
    else:
        print("Ação inválida. Use 'add' ou 'check'.")
        sys.exit(1)