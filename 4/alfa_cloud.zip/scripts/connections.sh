#!/bin/bash

# Script para gerenciamento de serviços de conexão

ACTION=$1
SERVICE=$2
PORT=$3
PID_DIR="/alfa_cloud/pids"
LOG_DIR="/alfa_cloud/logs"

# Verifica se o script está sendo executado como root
if [[ $EUID -ne 0 ]]; then
   echo "Este script deve ser executado como root"
   exit 1
fi

# Cria diretórios para PIDs e logs
mkdir -p "$PID_DIR" "$LOG_DIR"
chmod -R 755 "$PID_DIR" "$LOG_DIR"

case $SERVICE in
    websocket)
        if [[ "$ACTION" == "start" ]]; then
            # Exemplo: Inicia um servidor WebSocket (usar ferramenta como websocat)
            nohup websocat ws://0.0.0.0:$PORT > "$LOG_DIR/websocket.log" 2>&1 &
            echo $! > "$PID_DIR/websocket.pid"
            iptables -A INPUT -p tcp --dport "$PORT" -j ACCEPT
            echo "WebSocket iniciado na porta $PORT"
        elif [[ "$ACTION" == "stop" ]]; then
            kill $(cat "$PID_DIR/websocket.pid") 2>/dev/null
            rm -f "$PID_DIR/websocket.pid"
            iptables -D INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null
            echo "WebSocket parado"
        elif [[ "$ACTION" == "status" ]]; then
            if [[ -f "$PID_DIR/websocket.pid" && -n "$(ps -p $(cat "$PID_DIR/websocket.pid") -o pid=)" ]]; then
                echo "Ativo na porta $PORT"
            else
                echo "Desativado"
            fi
        fi
        ;;

    socks)
        if [[ "$ACTION" == "start" ]]; then
            # Exemplo: Inicia um proxy SOCKS (usar ferramenta como dante ou ss5)
            nohup danted -D -p "$PID_DIR/socks.pid" -f /etc/danted.conf > "$LOG_DIR/socks.log" 2>&1 &
            iptables -A INPUT -p tcp --dport "$PORT" -j ACCEPT
            echo "SOCKS iniciado na porta $PORT"
        elif [[ "$ACTION" == "stop" ]]; then
            kill $(cat "$PID_DIR/socks.pid") 2>/dev/null
            rm -f "$PID_DIR/socks.pid"
            iptables -D INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null
            echo "SOCKS parado"
        elif [[ "$ACTION" == "status" ]]; then
            if [[ -f "$PID_DIR/socks.pid" && -n "$(ps -p $(cat "$PID_DIR/socks.pid") -o pid=)" ]]; then
                echo "Ativo na porta $PORT"
            else
                echo "Desativado"
            fi
        fi
        ;;

    ssltunnel|sslproxy)
        if [[ "$ACTION" == "start" ]]; then
            # Exemplo: Inicia um túnel SSL (usar stunnel)
            nohup stunnel /etc/stunnel/stunnel.conf > "$LOG_DIR/$SERVICE.log" 2>&1 &
            echo $! > "$PID_DIR/$SERVICE.pid"
            iptables -A INPUT -p tcp --dport "$PORT" -j ACCEPT
            echo "$SERVICE iniciado na porta $PORT"
        elif [[ "$ACTION" == "stop" ]]; then
            kill $(cat "$PID_DIR/$SERVICE.pid") 2>/dev/null
            rm -f "$PID_DIR/$SERVICE.pid"
            iptables -D INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null
            echo "$SERVICE parado"
        elif [[ "$ACTION" == "status" ]]; then
            if [[ -f "$PID_DIR/$SERVICE.pid" && -n "$(ps -p $(cat "$PID_DIR/$SERVICE.pid") -o pid=)" ]]; then
                echo "Ativo na porta $PORT"
            else
                echo "Desativado"
            fi
        fi
        ;;

    badvpn)
        if [[ "$ACTION" == "start" ]]; then
            nohup badvpn-udpgw --listen-addr 0.0.0.0:$PORT > "$LOG_DIR/badvpn.log" 2>&1 &
            echo $! > "$PID_DIR/badvpn.pid"
            iptables -A INPUT -p udp --dport "$PORT" -j ACCEPT
            echo "BadVPN iniciado na porta $PORT"
        elif [[ "$ACTION" == "stop" ]]; then
            kill $(cat "$PID_DIR/badvpn.pid") 2>/dev/null
            rm -f "$PID_DIR/badvpn.pid"
            iptables -D INPUT -p udp --dport "$PORT" -j ACCEPT 2>/dev/null
            echo "BadVPN parado"
        elif [[ "$ACTION" == "status" ]]; then
            if [[ -f "$PID_DIR/badvpn.pid" && -n "$(ps -p $(cat "$PID_DIR/badvpn.pid") -o pid=)" ]]; then
                echo "Ativo na porta $PORT"
            else
                echo "Desativado"
            fi
        fi
        ;;

    udpgw)
        if [[ "$ACTION" == "start" ]]; then
            nohup badvpn-udpgw --listen-addr 0.0.0.0:$PORT > "$LOG_DIR/udpgw.log" 2>&1 &
            echo $! > "$PID_DIR/udpgw.pid"
            iptables -A INPUT -p udp --dport "$PORT" -j ACCEPT
            echo "UDPGW iniciado na porta $PORT"
        elif [[ "$ACTION" == "stop" ]]; then
            kill $(cat "$PID_DIR/udpgw.pid") 2>/dev/null
            rm -f "$PID_DIR/udpgw.pid"
            iptables -D INPUT -p udp --dport "$PORT" -j ACCEPT 2>/dev/null
            echo "UDPGW parado"
        elif [[ "$ACTION" == "status" ]]; then
            if [[ -f "$PID_DIR/udpgw.pid" && -n "$(ps -p $(cat "$PID_DIR/udpgw.pid") -o pid=)" ]]; then
                echo "Ativo na porta $PORT"
            else
                echo "Desativado"
            fi
        fi
        ;;

    slowdns)
        if [[ "$ACTION" == "start" ]]; then
            # Exemplo: Inicia SlowDNS (substituir por implementação real)
            echo "Iniciando SlowDNS na porta $PORT" > "$LOG_DIR/slowdns.log"
            echo $! > "$PID_DIR/slowdns.pid"
            iptables -A INPUT -p udp --dport "$PORT" -j ACCEPT
            echo "SlowDNS iniciado na porta $PORT"
        elif [[ "$ACTION" == "stop" ]]; then
            kill $(cat "$PID_DIR/slowdns.pid") 2>/dev/null
            rm -f "$PID_DIR/slowdns.pid"
            iptables -D INPUT -p udp --dport "$PORT" -j ACCEPT 2>/dev/null
            echo "SlowDNS parado"
        elif [[ "$ACTION" == "status" ]]; then
            if [[ -f "$PID_DIR/slowdns.pid" && -n "$(ps -p $(cat "$PID_DIR/slowdns.pid") -o pid=)" ]]; then
                echo "Ativo na porta $PORT"
            else
                echo "Desativado"
            fi
        fi
        ;;

    direct)
        if [[ "$ACTION" == "start" ]]; then
            # Exemplo: Conexão direta (substituir por implementação real)
            echo "Iniciando conexão direta na porta $PORT" > "$LOG_DIR/direct.log"
            echo $! > "$PID_DIR/direct.pid"
            iptables -A INPUT -p tcp --dport "$PORT" -j ACCEPT
            echo "Conexão direta iniciada na porta $PORT"
        elif [[ "$ACTION" == "stop" ]]; then
            kill $(cat "$PID_DIR/direct.pid") 2>/dev/null
            rm -f "$PID_DIR/direct.pid"
            iptables -D INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null
            echo "Conexão direta parada"
        elif [[ "$ACTION" == "status" ]]; then
            if [[ -f "$PID_DIR/direct.pid" && -n "$(ps -p $(cat "$PID_DIR/direct.pid") -o pid=)" ]]; then
                echo "Ativo na porta $PORT"
            else
                echo "Desativado"
            fi
        fi
        ;;
    *)
        echo "Uso: $0 {start|stop|status} {websocket|socks|ssltunnel|sslproxy|badvpn|udpgw|slowdns|direct} [port]"
        exit 1
        ;;
esac