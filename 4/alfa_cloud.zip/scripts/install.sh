#!/bin/bash

set -e

echo "[INFO] Instalando dependências do sistema..."
sudo apt update && sudo apt install -y python3 python3-venv python3-pip nginx sqlite3 curl unzip

APP_DIR="/alfa_cloud"

echo "[INFO] Criando ambiente virtual..."
python3 -m venv "$APP_DIR/venv"
source "$APP_DIR/venv/bin/activate"

echo "[INFO] Instalando dependências Python..."
pip install --upgrade pip
pip install -r "$APP_DIR/requirements.txt"
deactivate

echo "[INFO] Criando banco de dados..."
sqlite3 "$APP_DIR/alfa_cloud.db" < "$APP_DIR/db/create_db.sql"

echo "[INFO] Criando serviço systemd..."
sudo tee /etc/systemd/system/alfa_cloud.service > /dev/null <<EOF
[Unit]
Description=Alfa Cloud Gunicorn
After=network.target

[Service]
User=$USER
WorkingDirectory=$APP_DIR
ExecStart=$APP_DIR/venv/bin/gunicorn -b 127.0.0.1:5000 app.routes:app
Restart=always

[Install]
WantedBy=multi-user.target
EOF

echo "[INFO] Habilitando serviço..."
sudo systemctl daemon-reexec
sudo systemctl daemon-reload
sudo systemctl enable alfa_cloud
sudo systemctl restart alfa_cloud

echo "[INFO] Configurando Nginx..."
sudo cp "$APP_DIR/nginx.conf" /etc/nginx/sites-available/alfa_cloud
sudo ln -sf /etc/nginx/sites-available/alfa_cloud /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl restart nginx

echo "[SUCESSO] Sistema instalado e rodando em http://SEU_DOMÍNIO ou http://SEU_IP"
