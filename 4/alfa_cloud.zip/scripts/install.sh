#!/bin/bash

# Script de instalação para Alfa Cloud

# Verifica se o script está sendo executado como root
if [[ $EUID -ne 0 ]]; then
   echo "Este script deve ser executado como root"
   exit 1
fi

# Define variáveis
DOMAIN="avira.alfalemos.shop"  # Substitua pelo seu domínio
EMAIL="alfalemos21@gmail.com"  # Email para Let's Encrypt
APP_DIR="/alfa_cloud"
NGINX_CONF="$APP_DIR/nginx.conf"

# Atualiza o sistema
echo "[INFO] Atualizando o sistema..."
apt update && apt upgrade -y

# Instala dependências do sistema
echo "[INFO] Instalando dependências do sistema..."
apt install -y python3 python3-pip nginx sqlite3 certbot python3-certbot-nginx git ufw

# Instala dependências Python
echo "[INFO] Instalando dependências Python..."
pip3 install -r "$APP_DIR/requirements.txt"

# Cria diretório do banco de dados
echo "[INFO] Configurando banco de dados..."
mkdir -p "$APP_DIR/db"
chmod -R 755 "$APP_DIR/db"

# Cria o banco de dados SQLite
if [ -f "$APP_DIR/db/create_db.sql" ]; then
   sqlite3 "$APP_DIR/db/alfa_cloud.db" < "$APP_DIR/db/create_db.sql"
else
   echo "[ERRO] Arquivo create_db.sql não encontrado em $APP_DIR/db/"
   exit 1
fi

# Configura o Nginx
echo "[INFO] Configurando o Nginx..."
cp "$NGINX_CONF" /etc/nginx/sites-available/alfa_cloud
ln -s /etc/nginx/sites-available/alfa_cloud /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
systemctl restart nginx

# Configura SSL com Let's Encrypt
echo "[INFO] Configurando certificados SSL..."
certbot --nginx -d "$DOMAIN" -d "*.$DOMAIN" --non-interactive --agree-tos -m "$EMAIL" --redirect

# Configura firewall (UFW)
echo "[INFO] Configurando firewall..."
ufw allow 80
ufw allow 443
ufw allow 22
ufw --force enable

# Inicia o aplicativo Flask com Gunicorn
echo "[INFO] Iniciando o aplicativo Flask..."
pip3 install gunicorn
nohup gunicorn -w 4 -b 0.0.0.0:5000 --chdir "$APP_DIR" app:app > "$APP_DIR/app.log" 2>&1 &

# Configura serviços adicionais (exemplo: BadVPN)
echo "[INFO] Configurando serviços adicionais..."
if ! command -v badvpn-udpgw &> /dev/null; then
   apt install -y cmake build-essential
   git clone https://github.com/ambrop72/badvpn.git /tmp/badvpn
   cd /tmp/badvpn
   cmake . && make && make install
   cd -
   rm -rf /tmp/badvpn
fi

# Regras de iptables
echo "[INFO] Abrindo portas padrão..."
iptables -A INPUT -p tcp --dport 80 -j ACCEPT
iptables -A INPUT -p tcp --dport 443 -j ACCEPT
iptables -A INPUT -p tcp --dport 8080 -j ACCEPT
iptables -A INPUT -p udp --dport 7300 -j ACCEPT
iptables-save > /etc/iptables/rules.v4

echo "[SUCESSO] Instalação concluída!"
echo "Acesse https://$DOMAIN ou http://<IP_DO_SERVIDOR>"
echo "Logs do aplicativo em $APP_DIR/app.log"
