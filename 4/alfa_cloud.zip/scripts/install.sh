#!/bin/bash

# Script de instalação para Alfa Cloud

# Verifica se o script está sendo executado como root
if [[ $EUID -ne 0 ]]; then
   echo "Este script deve ser executado como root"
   exit 1
fi

# Define variáveis
DOMAIN="avira.alfalemos.shop"  # Substitua pelo seu domínio
EMAIL="alfalemos21@gmail.com"  # Email para Let's Encrypt
APP_DIR="/alfa_cloud"
NGINX_CONF="$APP_DIR/nginx.conf"

# Atualiza o sistema
echo "[INFO] Atualizando o sistema..."
apt update && apt upgrade -y

# Instala dependências
echo "[INFO] Instalando dependências..."
apt install -y python3 python3-pip nginx sqlite3 certbot python3-certbot-nginx git ufw iptables-persistent unzip curl

# Cria pasta do app e baixa o código
echo "[INFO] Baixando e extraindo projeto..."
mkdir -p "$APP_DIR"
cd "$APP_DIR"
curl -L -o alfa_cloud.zip https://github.com/sofrenoob/Gggggg/raw/main/4/alfa_cloud.zip
unzip -o alfa_cloud.zip
rm alfa_cloud.zip

# Instala dependências Python
echo "[INFO] Instalando dependências Python..."
pip3 install -r "$APP_DIR/requirements.txt"

# Configura o Nginx
echo "[INFO] Configurando o Nginx..."
cp "$NGINX_CONF" /etc/nginx/sites-available/alfa_cloud
ln -sf /etc/nginx/sites-available/alfa_cloud /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl restart nginx

# Configura SSL com Let's Encrypt
echo "[INFO] Configurando certificados SSL..."
certbot --nginx -d "$DOMAIN" -d "*.$DOMAIN" --non-interactive --agree-tos -m "$EMAIL" --redirect

# Firewall com UFW
echo "[INFO] Configurando firewall..."
ufw allow 80
ufw allow 443
ufw allow 22
ufw --force enable

# Cria banco de dados SQLite
echo "[INFO] Configurando banco de dados..."
if [[ -f "$APP_DIR/db/create_db.sql" ]]; then
   sqlite3 "$APP_DIR/alfa_cloud.db" < "$APP_DIR/db/create_db.sql"
   echo "[OK] Banco de dados criado."
else
   echo "[ERRO] Arquivo create_db.sql não encontrado em $APP_DIR/db/"
fi

# Inicia o app com Gunicorn
echo "[INFO] Iniciando o aplicativo Flask com Gunicorn..."
pip3 install gunicorn
nohup gunicorn -w 4 -b 0.0.0.0:5000 --chdir "$APP_DIR" app:app > "$APP_DIR/app.log" 2>&1 &

# Instala BadVPN se necessário
echo "[INFO] Configurando BadVPN (UDPGW)..."
if ! command -v badvpn-udpgw &> /dev/null; then
   apt install -y cmake build-essential
   git clone https://github.com/ambrop72/badvpn.git /tmp/badvpn
   cd /tmp/badvpn
   cmake . && make && make install
   cd -
   rm -rf /tmp/badvpn
fi

# Abre portas com iptables
echo "[INFO] Abrindo portas padrão..."
iptables -A INPUT -p tcp --dport 80 -j ACCEPT
iptables -A INPUT -p tcp --dport 443 -j ACCEPT
iptables -A INPUT -p tcp --dport 8080 -j ACCEPT
iptables -A INPUT -p udp --dport 7300 -j ACCEPT
iptables-save > /etc/iptables/rules.v4

echo "[SUCESSO] Instalação concluída!"
echo "Acesse: https://$DOMAIN"
echo "Log da aplicação: $APP_DIR/app.log"
