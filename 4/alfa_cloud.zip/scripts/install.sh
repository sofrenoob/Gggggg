#!/bin/bash

echo "[INFO] Instalando dependências do sistema..."
apt update
apt install -y python3 python3-venv python3-pip sqlite3 unzip nginx curl

echo "[INFO] Criando ambiente virtual..."
python3 -m venv /alfa_cloud/venv
source /alfa_cloud/venv/bin/activate

echo "[INFO] Instalando dependências Python..."
pip install --upgrade pip
pip install -r /alfa_cloud/requirements.txt

echo "[INFO] Configurando banco de dados..."
if [ -f /alfa_cloud/db/create_db.sql ]; then
    sqlite3 /alfa_cloud/db/alfa_cloud.db < /alfa_cloud/db/create_db.sql
else
    echo "[ERRO] SQL de criação de banco não encontrado!"
    exit 1
fi

echo "[INFO] Finalizando instalação..."
systemctl restart alfa_cloud
