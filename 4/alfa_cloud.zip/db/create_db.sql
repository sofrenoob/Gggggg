-- create_db.sql
-- Esquema do banco de dados para Alfa Cloud

-- Tabela para administradores
CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela para usuários SSH/VPN
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    active BOOLEAN DEFAULT 1
);

-- Tabela para proxies
CREATE TABLE IF NOT EXISTS proxies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    address TEXT NOT NULL UNIQUE,
    port INTEGER NOT NULL,
    type TEXT CHECK(type IN ('HTTP', 'SOCKS4', 'SOCKS5')) DEFAULT 'HTTP',
    status TEXT CHECK(status IN ('active', 'inactive', 'failed')) DEFAULT 'inactive',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_checked TIMESTAMP
);

-- Tabela para conexões (WebSocket, SOCKS, etc.)
CREATE TABLE IF NOT EXISTS connections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    type TEXT CHECK(type IN ('WebSocket', 'SOCKS', 'SSLTunnel', 'VPN')) NOT NULL,
    status TEXT CHECK(status IN ('active', 'inactive', 'failed')) DEFAULT 'inactive',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Tabela para configurações gerais
CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT NOT NULL UNIQUE,
    value TEXT NOT NULL
);

-- Dados iniciais para teste
INSERT OR IGNORE INTO admins (username, password) VALUES ('admin', 'admin123');
INSERT OR IGNORE INTO settings (key, value) VALUES ('site_name', 'Alfa Cloud');
INSERT OR IGNORE INTO settings (key, value) VALUES ('theme', 'dark');