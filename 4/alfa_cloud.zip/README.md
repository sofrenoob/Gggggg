# Alfa Cloud

**Alfa Cloud** é uma aplicação Flask para gerenciamento de conexões SSH, VPN e Proxies, com interface web, integração com scripts shell e configuração automatizada via systemd e Nginx.

---

## Requisitos

- Ubuntu 20.04+ ou Debian 11+
- Python 3.8+
- Acesso root ou permissões sudo

---

## Instalação

Execute os comandos abaixo para instalar automaticamente:

```bash
curl -L -o alfa_cloud.zip https://raw.githubusercontent.com/sofrenoob/Gggggg/main/4/alfa_cloud.zip
unzip alfa_cloud.zip -d /alfa_cloud
cd /alfa_cloud/scripts
chmod +x install.sh
./install.sh
