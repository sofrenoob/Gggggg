#!/bin/bash

# Script para configuração de subdomínios

SUBDOMAIN=$1
IP=$2
DOMAIN="avira.alfalemos.shop"  # Substitua pelo seu domínio
NGINX_CONF="/etc/nginx/sites-available/alfa_cloud"

# Verifica se o script está sendo executado como root
if [[ $EUID -ne 0 ]]; then
   echo "Este script deve ser executado como root"
   exit 1
fi

# Adiciona subdomínio ao Nginx
echo "Configurando subdomínio $SUBDOMAIN.$DOMAIN para $IP..."
cat <<EOL >> "$NGINX_CONF"
server {
    listen 80;
    listen [::]:80;
    server_name $SUBDOMAIN.$DOMAIN;

    location / {
        proxy_pass http://$IP;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }
}
EOL

# Testa e reinicia o Nginx
nginx -t && systemctl restart nginx
if [[ $? -eq 0 ]]; then
    echo "Nginx configurado com sucesso para $SUBDOMAIN.$DOMAIN"
else
    echo "Erro ao configurar o Nginx"
    exit 1
fi

# Atualiza DNS (exemplo, substituir por sua API de DNS)
# Exemplo com Cloudflare (ajustar com suas credenciais)
# CF_API_TOKEN="seu_token"
# CF_ZONE_ID="seu_zone_id"
# curl -X POST "https://api.cloudflare.com/client/v4/zones/$CF_ZONE_ID/dns_records" \
#      -H "Authorization: Bearer $CF_API_TOKEN" \
#      -H "Content-Type: application/json" \
#      --data "{\"type\":\"A\",\"name\":\"$SUBDOMAIN\",\"content\":\"$IP\",\"ttl\":3600,\"proxied\":false}"

echo "Subdomínio $SUBDOMAIN.$DOMAIN configurado para $IP"