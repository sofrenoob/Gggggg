#!/bin/bash

# Script para gerenciamento de usuários SSH

ACTION=$1
USERNAME=$2
PASSWORD=$3
CONNECTION_LIMIT=$4
BACKUP_DIR="/alfa_cloud/backups"
DB_PATH="/alfa_cloud/db/alfa_cloud.db"

# Verifica se o script está sendo executado como root
if [[ $EUID -ne 0 ]]; then
   echo "Este script deve ser executado como root"
   exit 1
fi

case $ACTION in
    create)
        # Cria usuário SSH
        useradd -m -s /bin/false "$USERNAME" 2>/dev/null
        echo "$USERNAME:$PASSWORD" | chpasswd
        # Configura limite de conexões (exemplo com PAM)
        echo "account required pam_limits.so" >> /etc/pam.d/sshd
        echo "$USERNAME hard maxlogins $CONNECTION_LIMIT" >> /etc/security/limits.conf
        echo "Usuário $USERNAME criado com limite de $CONNECTION_LIMIT conexões"
        ;;

    edit)
        # Edita senha e limite de conexões
        echo "$USERNAME:$PASSWORD" | chpasswd
        sed -i "/$USERNAME hard maxlogins/d" /etc/security/limits.conf
        echo "$USERNAME hard maxlogins $CONNECTION_LIMIT" >> /etc/security/limits.conf
        echo "Usuário $USERNAME atualizado"
        ;;

    delete)
        # Exclui usuário
        userdel -r "$USERNAME" 2>/dev/null
        sed -i "/$USERNAME hard maxlogins/d" /etc/security/limits.conf
        echo "Usuário $USERNAME excluído"
        ;;

    backup)
        # Faz backup dos usuários no banco de dados
        mkdir -p "$BACKUP_DIR"
        BACKUP_FILE="$BACKUP_DIR/users_$(date +%F_%H%M%S).sql"
        sqlite3 "$DB_PATH" ".dump user" > "$BACKUP_FILE"
        echo "Backup salvo em $BACKUP_FILE"
        ;;

    restore)
        # Restaura o último backup
        LAST_BACKUP=$(ls -t "$BACKUP_DIR/users_*.sql" | head -n 1)
        if [[ -f "$LAST_BACKUP" ]]; then
            sqlite3 "$DB_PATH" < "$LAST_BACKUP"
            echo "Backup restaurado de $LAST_BACKUP"
        else
            echo "Nenhum backup encontrado"
            exit 1
        fi
        ;;
    *)
        echo "Uso: $0 {create|edit|delete|backup|restore} [username] [password] [connection_limit]"
        exit 1
        ;;
esac