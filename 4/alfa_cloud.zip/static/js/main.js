// Funções interativas para Alfa Cloud

// Carrossel de banners
document.addEventListener('DOMContentLoaded', () => {
    const banners = document.querySelectorAll('.banner');
    let currentBanner = 0;

    if (banners.length > 0) {
        function showNextBanner() {
            banners[currentBanner].classList.add('hidden');
            currentBanner = (currentBanner + 1) % banners.length;
            banners[currentBanner].classList.remove('hidden');
        }

        // Troca de banner a cada 5 segundos
        setInterval(showNextBanner, 5000);

        // Exibe o primeiro banner
        banners[0].classList.remove('hidden');
    }
});

// Validação de formulários (exemplo para inputs numéricos)
document.querySelectorAll('input[type="number"]').forEach(input => {
    input.addEventListener('input', () => {
        if (input.value < 1) {
            input.value = 1; // Garante que o valor mínimo seja 1 (ex.: limite de conexões)
        }
    });
});

// Efeito de scroll suave para links internos
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});