# Alfa Cloud

Uma CDN avançada com gerenciador web, suporte a VPN, proxies (WebSocket, SOCKS, SSL, etc.), e",
" e interface moderna no estilo hacker futurista.

## Pré-requisitos

- Servidor Ubuntu 18.04
- Domínio/subdomínio configurado (ex.: `alfa-cloud.seudominio.com`)
- Acesso root

## Estrutura do Projeto

/var/www/alfa-cloud/ ├── backend/ │   ├── app.py │   ├── config.py │   ├── models.py │   ├── routes/ │   │   ├── admin.py │   │   ├── users.py │   │   ├── connections.py │   │   ├── proxies.py │   ├── static/ │   │   ├── css/ │   │   │   ├── style.css │   │   ├── js/ │   │   │   ├── main.js │   │   ├── images/ │   │       ├── banner1.jpg │   │       ├── banner2.jpg │   │       ├── whatsapp-icon.png │   ├── templates/ │   │   ├── base.html │   │   ├── index.html │   │   ├── admin.html │   │   ├── users.html │   │   ├── connections.html │   │   ├── proxies.html ├── scripts/ │   ├── setup_vpn.sh │   ├── setup_proxy.sh │   ├── setup_services.sh │   ├── setup_firewall.sh ├── nginx/ │   ├── alfa-cloud.conf ├── database/ │   ├── alfa_cloud.db ├── README.md


## Instalação

1. **Atualizar o sistema e instalar dependências básicas**:
   ```bash
   sudo apt update && sudo apt upgrade -y
   sudo apt install -y python3 python3-pip nginx sqlite3 git ufw fail2ban curl unzip cmake build-essential nodejs npm
   
   
   sudo mkdir -p /var/www/alfa-cloud/{backend/{routes,static/{css,js,images},templates},scripts,nginx,database}
sudo chown -R www-data:www-data /var/www/alfa-cloud
sudo chmod -R 755 /var/www/alfa-cloud


cd /var/www/alfa-cloud/backend
pip3 install flask flask-sqlalchemy


chmod +x /var/www/alfa-cloud/scripts/*.sh
sudo /var/www/alfa-cloud/scripts/setup_vpn.sh
sudo /var/www/alfa-cloud/scripts/setup_proxy.sh
sudo /var/www/alfa-cloud/scripts/setup_services.sh
sudo /var/www/alfa-cloud/scripts/setup_firewall.sh


cd /var/www/alfa-cloud/backend
python3 app.py

pip3 install gunicorn
gunicorn -w 4 -b 127.0.0.1:5000 app:app

journalctl -u <nome-do-serviço>




---

### Observações
1. **alfa-cloud.conf**:
   - Certifique-se de que o subdomínio está configurado no seu provedor de DNS para apontar para o IP do servidor.
   - O certificado SSL deve ser gerado com o Certbot antes de ativar a configuração.

2. **alfa_cloud.db**:
   - O arquivo é gerado automaticamente, mas a pasta `/var/www/alfa-cloud/database/` deve existir com as permissões corretas.
   - Faça backups regulares do banco de dados para evitar perda de dados.

3. **README.md**:
   - O README inclui instruções completas para instalação. Ajuste o subdomínio e outras configurações específicas (ex.: número do WhatsApp) conforme necessário.
   - Considere adicionar mais detalhes sobre manutenção ou monitoramento, dependendo das suas necessidades.

4. **Permissões**:
   - Garanta que o usuário do Nginx (`www-data`) tenha acesso aos arquivos:
     ```bash
     sudo chown -R www-data:www-data /var/www/alfa-cloud
     sudo chmod -R 755 /var/www/alfa-cloud
     ```

5. **Segurança**:
   - Configure autenticação para rotas sensíveis (ex.: `/admin`, `/users`) usando `flask-login` ou similar.
   - Monitore o Fail2Ban e os logs do Nginx para detectar tentativas de acesso não autorizado.