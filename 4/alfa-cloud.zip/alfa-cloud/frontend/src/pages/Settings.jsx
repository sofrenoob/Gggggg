import { useState } from "react";

export default function Settings() {
  const [banner, setBanner] = useState("");
  const [plans, setPlans] = useState([
    { id: 1, label: "1 login 30d R$20" },
    { id: 2, label: "2 logins 30d R$35" },
    { id: 3, label: "3 logins 30d R$50" }
  ]);

  const save = () => {
    alert("Configurações salvas (você deve implementar a API)");
  };

  return (
    <div className="page">
      <h2>Configurações Gerais</h2>

      <h3>Banner Home</h3>
      <input
        value={banner}
        onChange={e => setBanner(e.target.value)}
        placeholder="Texto do banner"
      />

      <h3>Planos</h3>
      {plans.map((p, i) => (
        <div key={p.id}>
          <input
            value={p.label}
            onChange={e => {
              const n = [...plans];
              n[i].label = e.target.value;
              setPlans(n);
            }}
          />
        </div>
      ))}

      <button onClick={save}>Salvar</button>
    </div>
  );
}
