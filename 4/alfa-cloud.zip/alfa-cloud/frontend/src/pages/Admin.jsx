import { useEffect, useState } from "react";
import axios from "axios";

export default function Admin() {
  const [stats, setStats] = useState({
    users: 0,
    proxies: 0,
    connectionsActive: 0,
  });

  const token = localStorage.getItem("token");

  useEffect(() => {
    const headers = { Authorization: `Bearer ${token}` };

    const fetchStats = async () => {
      try {
        const [usersRes, proxiesRes, connectionsRes] = await Promise.all([
          axios.get("/api/users", { headers }),
          axios.get("/api/proxies", { headers }),
          axios.get("/api/connections", { headers }),
        ]);

        setStats({
          users: usersRes.data.length,
          proxies: proxiesRes.data.length,
          connectionsActive: Object.values(connectionsRes.data).filter(
            (v) => v === "running"
          ).length,
        });
      } catch (error) {
        console.error("Erro ao buscar dados do painel:", error);
      }
    };

    fetchStats();
  }, []);

  return (
    <div className="page">
      <h2>Painel Admin</h2>
      <p>Usuários: {stats.users}</p>
      <p>Proxies: {stats.proxies}</p>
      <p>Conexões Ativas: {stats.connectionsActive}</p>
    </div>
  );
}
