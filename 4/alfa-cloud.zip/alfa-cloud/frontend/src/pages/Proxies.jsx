import { useEffect, useState } from "react";
import axios from "axios";

export default function Proxies() {
  const [list, setList] = useState([]);
  const [form, setForm] = useState({});
  const token = localStorage.getItem("token");

  const load = () =>
    axios
      .get("/api/proxies", { headers: { Authorization: `Bearer ${token}` } })
      .then(r => setList(r.data));

  useEffect(load, []);

  const create = () =>
    axios
      .post("/api/proxies", form, { headers: { Authorization: `Bearer ${token}` } })
      .then(() => {
        setForm({});
        load();
      });

  const remove = id =>
    axios
      .delete(`/api/proxies/${id}`, { headers: { Authorization: `Bearer ${token}` } })
      .then(load);

  return (
    <div className="page">
      <h2>Gerenciar Proxies</h2>
      <input placeholder="Nome" value={form.name || ''} onChange={e => setForm({ ...form, name: e.target.value })} />
      <input placeholder="Porta" type="number" value={form.port || ''} onChange={e => setForm({ ...form, port: +e.target.value })} />
      <input placeholder="Modo (ex: ws, ssl, dns...)" value={form.mode || ''} onChange={e => setForm({ ...form, mode: e.target.value })} />
      <button onClick={create}>Criar</button>

      <table className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Porta</th>
            <th>Modo</th>
            <th>Status</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          {list.map(p => (
            <tr key={p.id}>
              <td>{p.id}</td>
              <td>{p.name}</td>
              <td>{p.port}</td>
              <td>{p.mode}</td>
              <td>{p.status}</td>
              <td>
                <button onClick={() => remove(p.id)}>Excluir</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
