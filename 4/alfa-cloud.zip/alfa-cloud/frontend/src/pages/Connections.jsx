import { useEffect, useState } from "react";
import axios from "axios";

export default function Connections() {
  const [svc, setSvc] = useState({});
  const [sel, setSel] = useState({
    protocol: "WebSocket",
    action: "start",
    port: 8080,
  });

  const token = localStorage.getItem("token");

  const load = () => {
    axios
      .get("/api/connections", {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((r) => setSvc(r.data))
      .catch((err) => console.error("Erro ao carregar conexões:", err));
  };

  useEffect(load, []);

  const exec = () => {
    axios
      .post("/api/connections/action", sel, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then(load)
      .catch((err) => console.error("Erro ao executar ação:", err));
  };

  return (
    <div className="page">
      <h2>Gerenciar Conexões</h2>

      <select
        value={sel.protocol}
        onChange={(e) => setSel((s) => ({ ...s, protocol: e.target.value }))}
      >
        {Object.keys(svc).map((p) => (
          <option key={p}>{p}</option>
        ))}
      </select>

      <select
        value={sel.action}
        onChange={(e) => setSel((s) => ({ ...s, action: e.target.value }))}
      >
        <option value="start">Iniciar</option>
        <option value="stop">Parar</option>
      </select>

      <input
        type="number"
        placeholder="Porta"
        value={sel.port}
        onChange={(e) =>
          setSel((s) => ({ ...s, port: parseInt(e.target.value, 10) }))
        }
      />

      <button onClick={exec}>Executar</button>

      <h3>Status Atual</h3>
      <ul>
        {Object.entries(svc).map(([p, s]) => (
          <li key={p}>
            {p}: {s}
          </li>
        ))}
      </ul>
    </div>
  );
}
