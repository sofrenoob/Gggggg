import { useEffect, useState } from "react";
import axios from "axios";

export default function Users() {
  const [list, setList] = useState([]);
  const [form, setForm] = useState({});
  const token = localStorage.getItem("token");

  const load = () =>
    axios
      .get("/api/users", { headers: { Authorization: `Bearer ${token}` } })
      .then(r => setList(r.data));

  useEffect(load, []);

  const create = () =>
    axios
      .post("/api/users", form, { headers: { Authorization: `Bearer ${token}` } })
      .then(load);

  const remove = id =>
    axios
      .delete(`/api/users/${id}`, { headers: { Authorization: `Bearer ${token}` } })
      .then(load);

  return (
    <div className="page">
      <h2>Gerenciar Usuários</h2>
      <input placeholder="Usuário" onChange={e => setForm({ ...form, username: e.target.value })} />
      <input placeholder="Senha" type="password" onChange={e => setForm({ ...form, password: e.target.value })} />
      <input placeholder="Dias de validade" type="number" onChange={e => setForm({ ...form, validity: +e.target.value })} />
      <input placeholder="Máx. conexões" type="number" onChange={e => setForm({ ...form, maxConnections: +e.target.value })} />
      <button onClick={create}>Criar</button>

      <table className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Usuário</th>
            <th>Validade</th>
            <th>Máx.Conn</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          {list.map(u => (
            <tr key={u.id}>
              <td>{u.id}</td>
              <td>{u.username}</td>
              <td>{u.validity}d</td>
              <td>{u.maxConnections}</td>
              <td>
                <button onClick={() => remove(u.id)}>Excluir</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
