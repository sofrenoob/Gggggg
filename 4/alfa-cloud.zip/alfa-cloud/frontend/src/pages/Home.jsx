import BannerSlider from "../components/BannerSlider";
import FloatingWhatsApp from "../components/FloatingWhatsApp";

export default function Home() {
  return (
    <div className="page">
      <BannerSlider />

      <h2>Nossos Serviços</h2>
      <p>VPN, SSH, Proxy Inteligente e muito mais.</p>

      <h3>Teste Gratuito (1h)</h3>
      <button onClick={() => alert("Função de teste ainda não implementada.")}>
        Gerar Teste
      </button>

      <h3>Planos</h3>
      <ul>
        <li>1 login / 30 dias – R$ 20,00</li>
        <li>2 logins / 30 dias – R$ 35,00</li>
        <li>3 logins / 30 dias – R$ 50,00</li>
      </ul>

      <h3>App VPN</h3>
      <a href="/downloads/vpn-app.apk" className="btn-blue">
        Baixar App
      </a>

      <FloatingWhatsApp />
    </div>
  );
}
