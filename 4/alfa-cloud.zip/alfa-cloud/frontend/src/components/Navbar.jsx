import { Link } from "react-router-dom";
export default function Navbar() {
  return (
    <nav>
      <Link to="/">Home</Link>
      <Link to="/admin">Admin</Link>
      <Link to="/users">Usuários</Link>
      <Link to="/connections">Conexões</Link>
      <Link to="/proxies">Proxies</Link>
      <Link to="/settings">Configurações</Link>
    </nav>
  );
}