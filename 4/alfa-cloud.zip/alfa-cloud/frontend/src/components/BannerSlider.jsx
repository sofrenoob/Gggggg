const banners = [
  "/images/banners/1.jpg",
  "/images/banners/2.jpg",
  "/images/banners/3.jpg"
];
export default function BannerSlider() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((i+1)%banners.length), 5000);
    return ()=>clearInterval(t);
  }, [i]);
  return (
    <div style={{width:"100%",height:"200px",overflow:"hidden"}}>
      <img src={banners[i]} alt="" style={{width:"100%"}}/>
    </div>
  );
}