export default function FloatingWhatsApp(){
  return (
    <a
      href="https://wa.me/5511999999999"
      style={{
        position:"fixed", bottom:20, right:20,
        width:60, height:60, background:"#25D366",
        borderRadius:30, display:"flex",
        alignItems:"center", justifyContent:"center",
        boxShadow:"0 0 10px #0ff"
      }}
      target="_blank"
    >
      <img src="/images/whatsapp-icon.png" alt="WA" style={{width:30}}/>
    </a>
  );
}