#!/bin/bash

# Script para instalar e configurar BadVPN e SlowDNS

# Verificar se o script está sendo executado como root
if [ "$EUID" -ne 0 ]; then
    echo "Este script precisa ser executado como root. Use sudo."
    exit 1
fi

# Atualizar pacotes e instalar dependências
echo "Atualizando pacotes e instalando dependências..."
apt update && apt install -y git cmake build-essential unzip

# Instalar BadVPN
echo "Instalando BadVPN..."
git clone https://github.com/ambrop72/badvpn.git /tmp/badvpn
cd /tmp/badvpn
cmake . && make && make install
cd /var/www/alfa-cloud

# Criar serviço systemd para BadVPN
echo "Configurando serviço BadVPN..."
cat <<EOT > /etc/systemd/system/badvpn.service
[Unit]
Description=BadVPN UDPGW
After=network.target

[Service]
ExecStart=/usr/bin/badvpn-udpgw --listen-addr 127.0.0.1:7300
Restart=always

[Install]
WantedBy=multi-user.target
EOT

# Habilitar e iniciar o serviço BadVPN
systemctl daemon-reload
systemctl enable badvpn
systemctl start badvpn

# Verificar status do BadVPN
if systemctl is-active --quiet badvpn; then
    echo "BadVPN instalado e ativo com sucesso!"
else
    echo "Erro ao iniciar o BadVPN. Verifique os logs com 'journalctl -u badvpn'."
    exit 1
fi

# Instalar SlowDNS
echo "Instalando SlowDNS..."
wget https://github.com/darkssh/slowdns/archive/refs/heads/master.zip -O /tmp/slowdns.zip
unzip /tmp/slowdns.zip -d /tmp
cd /tmp/slowdns-master
chmod +x install.sh
./install.sh

# Criar serviço systemd para SlowDNS (exemplo, ajustar conforme necessário)
echo "Configurando serviço SlowDNS..."
cat <<EOT > /etc/systemd/system/slowdns.service
[Unit]
Description=SlowDNS Server
After=network.target

[Service]
ExecStart=/usr/local/bin/slowdns -p 53
Restart=always

[Install]
WantedBy=multi-user.target
EOT

# Habilitar e iniciar o serviço SlowDNS
systemctl daemon-reload
systemctl enable slowdns
systemctl start slowdns

# Verificar status do SlowDNS
if systemctl is-active --quiet slowdns; then
    echo "SlowDNS instalado e ativo com sucesso!"
else
    echo "Erro ao iniciar o SlowDNS. Verifique os logs com 'journalctl -u slowdns'."
    exit 1
fi

# Limpar arquivos temporários
rm -rf /tmp/badvpn /tmp/slowdns.zip /tmp/slowdns-master

echo "Configuração de BadVPN e SlowDNS concluída!"