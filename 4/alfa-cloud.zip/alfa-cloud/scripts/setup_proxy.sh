#!/bin/bash

# Script para instalar e configurar Squid e WebSocket

# Verificar se o script está sendo executado como root
if [ "$EUID" -ne 0 ]; then
    echo "Este script precisa ser executado como root. Use sudo."
    exit 1
fi

# Atualizar pacotes e instalar dependências
echo "Atualizando pacotes e instalando dependências..."
apt update && apt install -y squid nodejs npm

# Configurar Squid
echo "Configurando Squid..."
cat <<EOT > /etc/squid/squid.conf
http_port 3128
acl localnet src 0.0.0.0/0
http_access allow localnet
http_access deny all
EOT

# Habilitar e iniciar o serviço Squid
echo "Habilitando e iniciando o serviço Squid..."
systemctl enable squid
systemctl start squid

# Verificar status do Squid
if systemctl is-active --quiet squid; then
    echo "Squid instalado e ativo com sucesso!"
else
    echo "Erro ao iniciar o Squid. Verifique os logs com 'journalctl -u squid'."
    exit 1
fi

# Instalar WebSocket
echo "Instalando servidor WebSocket..."
npm install -g ws

# Criar um serviço systemd para o WebSocket
echo "Configurando serviço WebSocket..."
cat <<EOT > /etc/systemd/system/websocket.service
[Unit]
Description=WebSocket Server
After=network.target

[Service]
ExecStart=/usr/bin/npx ws --port 8080
Restart=always
User=nobody
Group=nogroup

[Install]
WantedBy=multi-user.target
EOT

# Habilitar e iniciar o serviço WebSocket
systemctl daemon-reload
systemctl enable websocket
systemctl start websocket

# Verificar status do WebSocket
if systemctl is-active --quiet websocket; then
    echo "WebSocket instalado e ativo com sucesso!"
else
    echo "Erro ao iniciar o WebSocket. Verifique os logs com 'journalctl -u websocket'."
    exit 1
fi

echo "Configuração de Squid e WebSocket concluída!"