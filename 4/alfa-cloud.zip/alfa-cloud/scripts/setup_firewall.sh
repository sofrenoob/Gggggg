#!/bin/bash

#26f5#!/bin/bash

# Script para configurar UFW e Fail2Ban

# Verificar se o script está sendo executado como root
if [ "$EUID" -ne 0 ]; then
    echo "Este script precisa ser executado como root. Use sudo."
    exit 1
fi

# Atualizar pacotes e instalar dependências
echo "Atualizando pacotes e instalando dependências..."
apt update && apt install -y ufw fail2ban

# Configurar UFW
echo "Configurando UFW..."
ufw default deny incoming
ufw default allow outgoing
ufw allow OpenSSH
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS
ufw allow 1194/udp  # OpenVPN
ufw allow 3128/tcp  # Squid
ufw allow 8080/tcp  # WebSocket
ufw allow 7300/udp  # BadVPN
ufw allow 53/udp    # SlowDNS

# Habilitar UFW
echo "Habilitando UFW..."
ufw --force enable

# Verificar status do UFW
if ufw status | grep -q "Status: active"; then
    echo "UFW configurado e ativo com sucesso!"
else
    echo "Erro ao configurar o UFW. Verifique com 'ufw status'."
    exit 1
fi

# Configurar Fail2Ban
echo "Configurando Fail2Ban..."
cat <<EOT > /etc/fail2ban/jail.local
[DEFAULT]
bantime  = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true
port    = ssh
filter  = sshd
maxretry = 5
EOT

# Habilitar e iniciar o Fail2Ban
systemctl enable fail2ban
systemctl start fail2ban

# Verificar status do Fail2Ban
if systemctl is-active --quiet fail2ban; then
    echo "Fail2Ban configurado e ativo com sucesso!"
else
    echo "Erro ao iniciar o Fail2Ban. Verifique os logs com 'journalctl -u fail2ban'."
    exit 1
fi

echo "Configuração de UFW e Fail2Ban concluída!"