#!/bin/bash

# Script para instalar e configurar o OpenVPN

# Verificar se o script está sendo executado como root
if [ "$EUID" -ne 0 ]; then
    echo "Este script precisa ser executado como root. Use sudo."
    exit 1
fi

# Atualizar pacotes e instalar dependências
echo "Atualizando pacotes e instalando dependências..."
apt update && apt install -y curl

# Baixar e executar o script de instalação do OpenVPN
echo "Baixando script de instalação do OpenVPN..."
wget https://raw.githubusercontent.com/Angristan/openvpn-install/master/openvpn-install.sh -O openvpn-install.sh

# Tornar o script executável
chmod +x openvpn-install.sh

# Executar o script de instalação
echo "Executando instalação do OpenVPN..."
./openvpn-install.sh

# Habilitar e iniciar o serviço OpenVPN
echo "Habilitando e iniciando o serviço OpenVPN..."
systemctl enable openvpn
systemctl start openvpn

# Verificar status do serviço
if systemctl is-active --quiet openvpn; then
    echo "OpenVPN instalado e ativo com sucesso!"
else
    echo "Erro ao iniciar o OpenVPN. Verifique os logs com 'journalctl -u openvpn'."
    exit 1
fi

# Limpar arquivos temporários
rm openvpn-install.sh

echo "Configuração do OpenVPN concluída!"