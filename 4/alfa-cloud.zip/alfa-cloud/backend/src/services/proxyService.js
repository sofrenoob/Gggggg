const { exec } = require('child_process');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const DBSOURCE = path.join(__dirname, '../database/data.db');
const SCRIPTS_DIR = path.join(__dirname, '../scripts');

function syncProxyModes() {
  const db = new sqlite3.Database(DBSOURCE);
  db.all('SELECT * FROM modes', (err, modes) => {
    if (err) return console.error(err);
    modes.forEach(mode => {
      const scriptPath = path.join(SCRIPTS_DIR, mode.script);
      exec(`pkill -f ${mode.script}`, () => {
        if (mode.status === 'running') {
          const cmd = `${scriptPath} --host ${mode.host} --port ${mode.port} --path ${mode.path}`;
          exec(cmd, (err) => {
            if (err) console.error(`Erro no modo ${mode.name}:`, err);
            else console.log(`Modo ${mode.name} iniciado`);
          });
        }
      });
    });
    db.close();
  });
}

module.exports = { syncProxyModes };