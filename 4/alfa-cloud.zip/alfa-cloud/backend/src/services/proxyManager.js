const { exec } = require("child_process");
const fs = require("fs");
const path = require("path");

const PROTOCOLS = [
  "websocket",
  "socks",
  "ssltunnel",
  "sslproxy",
  "badvpn",
  "slowdns",
  "direct"
];

function systemctl(cmd, service) {
  return new Promise((resolve, reject) => {
    exec(`systemctl ${cmd} ${service}`, (err, stdout, stderr) => {
      if (err) return reject(stderr);
      resolve(stdout);
    });
  });
}

// Gera (se necessário) um unit file em /etc/systemd/system/proxy-<protocol>@.service
function ensureUnit(protocol) {
  const unitName = `proxy-${protocol}@.service`;
  const unitPath = `/etc/systemd/system/${unitName}`;
  if (!fs.existsSync(unitPath)) {
    const script = `/usr/local/bin/${protocol}-proxy.sh`;
    const content = `
[Unit]
Description=Proxy ${protocol.toUpperCase()} Service on port %i
After=network.target

[Service]
Type=simple
ExecStart=${script} %i
Restart=on-failure

[Install]
WantedBy=multi-user.target
`.trim();
    fs.writeFileSync(unitPath, content, { mode: 0o644 });
    // recarrega o systemd
    exec("systemctl daemon-reload", () => {});
  }
}

async function toggleService(protocol, action, port) {
  protocol = protocol.toLowerCase();
  if (!PROTOCOLS.includes(protocol))
    throw new Error(`Protocolo inválido: ${protocol}`);

  ensureUnit(protocol);
  const svc = `proxy-${protocol}@${port}.service`;

  if (action === "start") {
    await systemctl("enable", svc);
    await systemctl("start", svc);
  } else if (action === "stop") {
    await systemctl("stop", svc);
    await systemctl("disable", svc);
  } else {
    throw new Error(`Ação inválida: ${action}`);
  }
}

// Ativa/Desativa proxies existentes (sem port)
async function toggleProxy(row, action) {
  return toggleService(row.protocol, action, row.port);
}

// Lista status de todos os protocolos (consulta via systemctl)
async function listServices() {
  const out = {};
  for (let p of PROTOCOLS) {
    try {
      const l = execSync(`systemctl is-active proxy-${p}@*`).toString().trim();
      out[p] = l;
    } catch {
      out[p] = "inactive";
    }
  }
  return out;
}

module.exports = { toggleProxy, listServices, toggleService };