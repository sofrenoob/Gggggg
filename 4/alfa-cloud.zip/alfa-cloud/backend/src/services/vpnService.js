const fs = require('fs');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const DBSOURCE = path.join(__dirname, '../database/data.db');
const CHAP_SECRETS = '/etc/ppp/chap-secrets';

function syncVpnUsers() {
  const db = new sqlite3.Database(DBSOURCE);
  db.all('SELECT username, vpn_password FROM users', (err, rows) => {
    if (err) return console.error(err);
    const lines = rows.map(u => `${u.username} * ${u.vpn_password} *`).join('\n') + '\n';
    fs.writeFile(CHAP_SECRETS, lines, { mode: 0o600 }, err => {
      if (err) console.error(err);
      else console.log('chap-secrets atualizado');
    });
    db.close();
  });
}

module.exports = { syncVpnUsers };