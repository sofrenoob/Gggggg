const router = require("express").Router();
const { getDb } = require("../models/db");
const pm = require("../services/proxyManager");
const jwt = require("jsonwebtoken");
const JWT_SECRET = process.env.JWT_SECRET;

router.use((req, res, next) => {
  const auth = req.headers.authorization?.split(" ")[1];
  if (!auth) return res.status(401).end();
  try { jwt.verify(auth, JWT_SECRET); next(); }
  catch { res.status(401).end(); }
});

// Listar
router.get("/", (req, res) => {
  getDb().all("SELECT * FROM proxies", (e, rows) =>
    e ? res.status(500).json(e) : res.json(rows)
  );
});

// Criar
router.post("/", (req, res) => {
  const { ip, port, protocol } = req.body;
  getDb().run(
    "INSERT INTO proxies (ip,port,protocol) VALUES (?,?,?)",
    [ip, port, protocol],
    function (e) {
      if (e) return res.status(400).json(e);
      res.json({ id: this.lastID });
    }
  );
});

// Editar / Status / Start-Stop
router.post("/:id/action", async (req, res) => {
  const { id } = req.params;
  const { action } = req.body; // start ou stop
  const row = await new Promise(r =>
    getDb().get("SELECT * FROM proxies WHERE id=?", id, (_, d) => r(d))
  );
  if (!row) return res.status(404).end();
  try {
    await pm.toggleProxy(row, action);
    const status = action === "start" ? "on" : "off";
    getDb().run("UPDATE proxies SET status=? WHERE id=?", [status, id]);
    res.json({ status });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Deletar
router.delete("/:id", (req, res) => {
  getDb().run("DELETE FROM proxies WHERE id=?", req.params.id, e =>
    e ? res.status(500).json(e) : res.json({ deleted: true })
  );
});

module.exports = router;