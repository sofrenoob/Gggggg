const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const dbInit = require('../models/db');
const { syncProxyModes } = require('../services/proxyService');

let db;
dbInit().then(() => {
  const sqlite3 = require('sqlite3').verbose();
  const path = require('path');
  const DBSOURCE = path.join(__dirname, '../database/data.db');
  db = new sqlite3.Database(DBSOURCE);
});

router.get('/', authMiddleware, (req, res) => {
  db.all('SELECT * FROM modes', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Falha ao listar modos' });
    res.json(rows);
  });
});

router.post('/', authMiddleware, (req, res) => {
  const { name,type,host,port,path,script } = req.body;
  if (!name||!type||!host||!port||!script) return res.status(400).json({ error: 'Dados incompletos' });
  db.run('INSERT INTO modes (name,type,host,port,path,script) VALUES (?,?,?,?,?,?)', [name,type,host,port,path||'',script], function(err) {
    if (err) return res.status(500).json({ error: 'Erro ao criar modo' });
    syncProxyModes();
    res.status(201).json({ id: this.lastID, name });
  });
});

router.put('/:id', authMiddleware, (req, res) => {
  const { id } = req.params;
  const { name,type,host,port,path,script,status } = req.body;
  db.run('UPDATE modes SET name=?,type=?,host=?,port=?,path=?,script=?,status=? WHERE id=?', [name,type,host,port,path||'',script,status||'stopped',id], function(err) {
    if (err) return res.status(500).json({ error: 'Erro ao atualizar modo' });
    syncProxyModes();
    res.json({ id });
  });
});

router.delete('/:id', authMiddleware, (req, res) => {
  const { id } = req.params;
  db.run('DELETE FROM modes WHERE id=?', [id], function(err) {
    if (err) return res.status(500).json({ error: 'Erro ao excluir modo' });
    syncProxyModes();
    res.json({ deleted: id });
  });
});

module.exports = router;