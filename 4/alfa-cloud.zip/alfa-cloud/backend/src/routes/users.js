const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const dbInit = require('../models/db');
const authMiddleware = require('../middleware/auth');
const { syncVpnUsers } = require('../services/vpnService');

let db;
dbInit().then(() => {
  const sqlite3 = require('sqlite3').verbose();
  const path = require('path');
  const DBSOURCE = path.join(__dirname, '../database/data.db');
  db = new sqlite3.Database(DBSOURCE);
});

router.get('/', authMiddleware, (req, res) => {
  db.all('SELECT id, username FROM users', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Erro ao listar usuários' });
    res.json(rows);
  });
});

router.post('/', authMiddleware, async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Dados incompletos' });

  try {
    const hash = await bcrypt.hash(password, 10);
    const vpnPass = password;
    db.run('INSERT INTO users (username,password,vpn_password) VALUES (?,?,?)', [username, hash, vpnPass], function(err) {
      if (err) return res.status(500).json({ error: 'Usuário já existe' });
      syncVpnUsers();
      res.status(201).json({ id: this.lastID, username });
    });
  } catch {
    res.status(500).json({ error: 'Erro ao processar senha' });
  }
});

router.put('/:id', authMiddleware, async (req, res) => {
  const { id } = req.params;
  const { password } = req.body;
  if (!password) return res.status(400).json({ error: 'Nova senha não informada' });

  try {
    const hash = await bcrypt.hash(password, 10);
    const vpnPass = password;
    db.run('UPDATE users SET password=?,vpn_password=? WHERE id=?', [hash, vpnPass, id], function(err) {
      if (err) return res.status(500).json({ error: 'Erro ao atualizar' });
      syncVpnUsers();
      res.json({ id });
    });
  } catch {
    res.status(500).json({ error: 'Erro no hash' });
  }
});

router.delete('/:id', authMiddleware, (req, res) => {
  const { id } = req.params;
  db.run('DELETE FROM users WHERE id=?', [id], function(err) {
    if (err) return res.status(500).json({ error: 'Erro ao excluir' });
    syncVpnUsers();
    res.json({ deleted: id });
  });
});

module.exports = router;