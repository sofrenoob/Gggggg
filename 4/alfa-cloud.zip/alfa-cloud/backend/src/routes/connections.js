const router = require("express").Router();
const pm = require("../services/proxyManager");
const jwt = require("jsonwebtoken");
const JWT_SECRET = process.env.JWT_SECRET;

router.use((req, res, next) => {
  const auth = req.headers.authorization?.split(" ")[1];
  if (!auth) return res.status(401).end();
  try { jwt.verify(auth, JWT_SECRET); next(); }
  catch { res.status(401).end(); }
});

const protocols = ["WebSocket","Socks","ssltunnel","sslproxy","badvpn","slowdns","direct"];

// Listar protocolos e status (stub)
router.get("/", async (req, res) => {
  const status = await pm.listServices();
  res.json(status);
});

// Start/Stop
router.post("/action", async (req, res) => {
  const { protocol, action, port } = req.body;
  if (!protocols.includes(protocol)) return res.status(400).json({ error: "Protocolo inválido" });
  try {
    await pm.toggleService(protocol, action, port);
    res.json({ protocol, status: action === "start" ? "running" : "stopped" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;