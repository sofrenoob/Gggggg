class Config:
    # Chave secreta para sessões e segurança (substitua por uma chave forte e única)
    SECRET_KEY = 'sua-chave-secreta-aqui-mude-isso'

    # URI do banco de dados SQLite
    SQLALCHEMY_DATABASE_URI = 'sqlite:///../database/alfa_cloud.db'

    # Desativar rastreamento de modificações para melhorar desempenho
    SQLALCHEMY_TRACK_MODIFICATIONS = False