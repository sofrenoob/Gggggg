from flask import Flask, render_template
from config import Config
from models import db
from routes.admin import admin_bp
from routes.users import users_bp
from routes.connections import connections_bp
from routes.proxies import proxies_bp

# Inicializar a aplicação Flask
app = Flask(__name__)
app.config.from_object(Config)

# Inicializar o banco de dados
db.init_app(app)

# Registrar blueprints (rotas)
app.register_blueprint(admin_bp, url_prefix='/admin')
app.register_blueprint(users_bp, url_prefix='/users')
app.register_blueprint(connections_bp, url_prefix='/connections')
app.register_blueprint(proxies_bp, url_prefix='/proxies')

# Rota para a página inicial
@app.route('/')
def index():
    return render_template('index.html')

# Criar tabelas do banco de dados na primeira execução
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=5000, debug=True)