from flask import Blueprint, render_template, request, redirect, url_for
import subprocess

connections_bp = Blueprint('connections', __name__)

# Função auxiliar para verificar status do serviço
def check_service_status(service_name):
    try:
        subprocess.check_output(f'systemctl is-active {service_name}', shell=True)
        return 'Ativo'
    except subprocess.CalledProcessError:
        return 'Inativo'

@connections_bp.route('/')
def index():
    services = [
        {'name': 'WebSocket', 'service': 'websocket', 'port': 8080, 'status': check_service_status('websocket')},
        {'name': 'SOCKS', 'service': 'squid', 'port': 3128, 'status': check_service_status('squid')},
        {'name': 'SSL Tunnel', 'service': 'stunnel', 'port': 443, 'status': check_service_status('stunnel')},
        {'name': 'BadVPN UDPGW', 'service': 'badvpn', 'port': 7300, 'status': check_service_status('badvpn')},
        {'name': 'SlowDNS', 'service': 'slowdns', 'port': 53, 'status': check_service_status('slowdns')}
    ]
    return render_template('connections.html', services=services)

@connections_bp.route('/toggle/<service>', methods=['POST'])
def toggle_service(service):
    action = request.form.get('action')
    if action == 'activate':
        subprocess.run(f'sudo systemctl start {service}', shell=True)
    else:
        subprocess.run(f'sudo systemctl stop {service}', shell=True)
    return redirect(url_for('connections.index'))

@connections_bp.route('/change_port/<service>', methods=['POST'])
def change_port(service):
    new_port = request.form.get('port')
    # Exemplo: Alterar porta no arquivo de configuração (depende do serviço)
    if service == 'squid':
        subprocess.run(f"sudo sed -i 's/http_port .*/http_port {new_port}/' /etc/squid/squid.conf", shell=True)
        subprocess.run('sudo systemctl restart squid', shell=True)
    # Adicione lógica para outros serviços
    return redirect(url_for('connections.index'))