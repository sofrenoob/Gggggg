from flask import Blueprint, render_template, request, redirect, url_for
from models import db
import os
from werkzeug.utils import secure_filename

admin_bp = Blueprint('admin', __name__)

# Configuração para upload de banners
UPLOAD_FOLDER = '/var/www/alfa-cloud/backend/static/images/'
ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@admin_bp.route('/', methods=['GET'])
def index():
    # Exibir painel de administração
    return render_template('admin.html')

@admin_bp.route('/update_banners', methods=['POST'])
def update_banners():
    # Processar upload de banners
    if 'banner1' in request.files:
        file = request.files['banner1']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(UPLOAD_FOLDER, 'banner1.jpg'))
    
    if 'banner2' in request.files:
        file = request.files['banner2']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(UPLOAD_FOLDER, 'banner2.jpg'))
    
    return redirect(url_for('admin.index'))

@admin_bp.route('/update_info', methods=['POST'])
def update_info():
    # Atualizar informações da página inicial (exemplo: salvar em arquivo ou banco)
    about_text = request.form.get('about_text')
    # Aqui você pode salvar o texto em um arquivo ou banco de dados
    with open('/var/www/alfa-cloud/backend/static/about.txt', 'w') as f:
        f.write(about_text)
    return redirect(url_for('admin.index'))