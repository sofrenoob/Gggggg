from flask import Blueprint, render_template, request, redirect, url_for
from models import db, User
import datetime
import json
import os

users_bp = Blueprint('users', __name__)

@users_bp.route('/create', methods=['GET', 'POST'])
def create_user():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        expiry = datetime.datetime.strptime(request.form['expiry'], '%Y-%m-%d')
        limit = int(request.form['limit'])
        
        # Verificar se o usuário já existe
        if User.query.filter_by(username=username).first():
            return render_template('users.html', action='create', error='Usuário já existe')
        
        user = User(username=username, password=password, expiry_date=expiry, connection_limit=limit)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('users.list_users'))
    return render_template('users.html', action='create')

@users_bp.route('/list')
def list_users():
    users = User.query.all()
    return render_template('users.html', users=users, action='list')

@users_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_user(id):
    user = User.query.get_or_404(id)
    if request.method == 'POST':
        user.password = request.form['password']
        user.expiry_date = datetime.datetime.strptime(request.form['expiry'], '%Y-%m-%d')
        user.connection_limit = int(request.form['limit'])
        db.session.commit()
        return redirect(url_for('users.list_users'))
    return render_template('users.html', action='edit', user=user)

@users_bp.route('/delete/<int:id>')
def delete_user(id):
    user = User.query.get_or_404(id)
    db.session.delete(user)
    db.session.commit()
    return redirect(url_for('users.list_users'))

@users_bp.route('/remove_expired')
def remove_expired():
    today = datetime.datetime.now()
    expired_users = User.query.filter(User.expiry_date < today).all()
    for user in expired_users:
        db.session.delete(user)
    db.session.commit()
    return redirect(url_for('users.list_users'))

@users_bp.route('/backup')
def backup_users():
    users = User.query.all()
    backup_data = [{
        'username': user.username,
        'password': user.password,
        'expiry_date': user.expiry_date.isoformat(),
        'connection_limit': user.connection_limit
    } for user in users]
    
    with open('/var/www/alfa-cloud/database/users_backup.json', 'w') as f:
        json.dump(backup_data, f)
    return redirect(url_for('users.list_users'))

@users_bp.route('/restore')
def restore_users():
    try:
        with open('/var/www/alfa-cloud/database/users_backup.json', 'r') as f:
            backup_data = json.load(f)
        
        for data in backup_data:
            user = User(
                username=data['username'],
                password=data['password'],
                expiry_date=datetime.datetime.fromisoformat(data['expiry_date']),
                connection_limit=data['connection_limit']
            )
            if not User.query.filter_by(username=user.username).first():
                db.session.add(user)
        db.session.commit()
    except FileNotFoundError:
        return render_template('users.html', action='list', error='Backup não encontrado')
    return redirect(url_for('users.list_users'))