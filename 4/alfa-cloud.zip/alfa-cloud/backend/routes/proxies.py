from flask import Blueprint, render_template, request, redirect, url_for
from models import db, Proxy
import socket
import time

proxies_bp = Blueprint('proxies', __name__)

@proxies_bp.route('/')
def index():
    proxies = Proxy.query.all()
    return render_template('proxies.html', proxies=proxies)

@proxies_bp.route('/add', methods=['POST'])
def add_proxy():
    host = request.form['host']
    port = int(request.form['port'])
    
    # Verificar se o proxy já existe
    if Proxy.query.filter_by(host=host, port=port).first():
        return render_template('proxies.html', proxies=Proxy.query.all(), error='Proxy já existe')
    
    proxy = Proxy(host=host, port=port, status='ativo')
    db.session.add(proxy)
    db.session.commit()
    return redirect(url_for('proxies.index'))

@proxies_bp.route('/check/<int:id>')
def check_proxy(id):
    proxy = Proxy.query.get_or_404(id)
    try:
        # Testar conexão com o proxy
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        result = sock.connect_ex((proxy.host, proxy.port))
        sock.close()
        proxy.status = 'ativo' if result == 0 else 'inativo'
    except:
        proxy.status = 'inativo'
    db.session.commit()
    return redirect(url_for('proxies.index'))

@proxies_bp.route('/delete/<int:id>')
def delete_proxy(id):
    proxy = Proxy.query.get_or_404(id)
    db.session.delete(proxy)
    db.session.commit()
    return redirect(url_for('proxies.index'))

@proxies_bp.route('/configure', methods=['POST'])
def configure_proxy():
    timeout = int(request.form.get('timeout', 5))
    retry = int(request.form.get('retry', 3))
    # Salvar configurações do serviço inteligente (exemplo: arquivo de config)
    config = {'timeout': timeout, 'retry': retry}
    with open('/var/www/alfa-cloud/backend/static/proxy_config.json', 'w') as f:
        json.dump(config, f)
    return redirect(url_for('proxies.index'))