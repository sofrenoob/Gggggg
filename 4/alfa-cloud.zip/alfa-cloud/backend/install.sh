#!/usr/bin/env bash
set -e

ENV_FILE=".env"
if [ ! -f "$ENV_FILE" ]; then
  ADMIN_PASS=$(openssl rand -base64 16)
  JWT_SECRET=$(openssl rand -hex 32)
  cat <<EOF > "$ENV_FILE"
ADMIN_USER=admin
ADMIN_PASS=$ADMIN_PASS
JWT_SECRET=$JWT_SECRET
BACKEND_PORT=5000
EOF
  echo "Admin: admin / $ADMIN_PASS"
fi

chmod +x backend/scripts/*.sh

docker-compose up -d --build