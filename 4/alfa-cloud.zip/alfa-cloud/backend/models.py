from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

# Inicializar o SQLAlchemy
db = SQLAlchemy()

# Modelo para a tabela de usuários
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    expiry_date = db.Column(db.DateTime, nullable=False)
    connection_limit = db.Column(db.Integer, default=1)

# Modelo para a tabela de proxies
class Proxy(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    host = db.Column(db.String(100), nullable=False)
    port = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(20), default='ativo')