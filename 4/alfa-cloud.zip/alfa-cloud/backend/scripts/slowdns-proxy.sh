#!/usr/bin/env bash
#
# SlowDNS Tunnel Client
# Repositório: https://github.com/xjasonlyu/slowdns
#
# Uso: slowdns-proxy.sh <porta>
# Inicia slowdns-client apontando para o servidor remoto.
#

PORT=${1:?Informe a porta}
REMOTESRV="example.dyndns.io:5300"
KEY="/etc/slowdns/server.pub"

exec /usr/local/bin/slowdns-client \
     -r ${REMOTESRV} \
     -l :${PORT} \
     -k ${KEY} \
     -v