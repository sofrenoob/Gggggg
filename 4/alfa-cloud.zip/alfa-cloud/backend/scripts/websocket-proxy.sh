#!/usr/bin/env bash
#
# WebSocket → TCP tunnel usando websocat
# Repositório: https://github.com/vi/websocat
#
# Uso: websocket-proxy.sh <porta>
# Escuta WS em 0.0.0.0:<porta> e repassa para 127.0.0.1:22 (SSH)
#

PORT=${1:?Informe a porta}
exec /usr/local/bin/websocat \
     "ws-l:0.0.0.0:${PORT},reuseaddr,fork" \
     "tcp:127.0.0.1:22"