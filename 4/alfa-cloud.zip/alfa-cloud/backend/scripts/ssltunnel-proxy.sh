#!/usr/bin/env bash
#
# SSL/TLS tunnel com stunnel4
# Repositório: https://www.stunnel.org/
#
# Uso: ssltunnel-proxy.sh <porta>
# Gera /etc/stunnel/INSTANCE-<porta>.conf e executa stunnel em primeiro plano.
#

PORT=${1:?Informe a porta}
CONF="/etc/stunnel/instance-${PORT}.conf"

# Gera config se não existir
if [ ! -f "${CONF}" ]; then
  cat >"${CONF}" <<EOF
cert = /etc/stunnel/stunnel.pem
pid = /var/run/stunnel-${PORT}.pid
foreground = yes

[ssh]
accept = ${PORT}
connect = 127.0.0.1:22
EOF
fi

exec /usr/bin/stunnel "${CONF}"