#!/usr/bin/env bash
#
# tun2socks via badvpn
# Repositório: https://github.com/ambrop72/badvpn
#
# Uso: badvpn-proxy.sh <porta>
# Inicia badvpn-tun2socks redirecionando SOCKS em 127.0.0.1:<porta>
#

PORT=${1:?Informe a porta}

exec /usr/local/bin/badvpn-tun2socks \
     --tundev tun0 \
     --netif-ipaddr 10.0.0.2 \
     --netif-netmask 255.255.255.0 \
     --socks-server-addr 127.0.0.1:${PORT}