#!/usr/bin/env bash
#
# Redirecionamento TCP direto com socat
# Repositório: http://www.dest-unreach.org/socat/
#
# Uso: direct-proxy.sh <porta>
# Escuta 0.0.0.0:<porta> e encaminha para remote.server.com:80
#

PORT=${1:?Informe a porta}
REMOTE_HOST="remote.server.com"
REMOTE_PORT=80

exec /usr/bin/socat \
     TCP-LISTEN:${PORT},reuseaddr,fork \
     TCP:${REMOTE_HOST}:${REMOTE_PORT}