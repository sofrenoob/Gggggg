#!/usr/bin/env bash
#
# SOCKS5 dinâmico via OpenSSH
# Cliente SSH nativo
#
# Uso: socks-proxy.sh <porta> [usuário@host]
# Se host não for passado, assume localhost.
#

PORT=${1:?Informe a porta}
TARGET=${2:-localhost}
exec /usr/bin/ssh -N -D 0.0.0.0:${PORT} ${TARGET}