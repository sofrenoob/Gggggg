import asyncio
import websockets

async def handler(websocket, path):
    while True:
        data = await websocket.recv()
        print(f"Recebido: {data}")
        await websocket.send("Conexão WebSocket ativa")

start_server = websockets.serve(handler, "0.0.0.0", 80)

asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()
