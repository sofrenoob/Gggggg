#!/usr/bin/env bash
#
# HTTPS (SSL) Proxy usando HAProxy
# Repositório: https://github.com/haproxy/haproxy
#
# Uso: sslproxy-proxy.sh <porta>
# Gera /etc/haproxy/haproxy-<porta>.cfg e roda o haproxy no foreground.
#

PORT=${1:?Informe a porta}
HAP_CFG="/etc/haproxy/haproxy-${PORT}.cfg"
CERT="/etc/ssl/certs/your_cert.pem"
KEY="/etc/ssl/private/your_key.pem"

# Gera config se não existir
if [ ! -f "${HAP_CFG}" ]; then
  cat >"${HAP_CFG}" <<EOF
global
    daemon
    maxconn 256

defaults
    mode tcp
    timeout connect 10s
    timeout client  1m
    timeout server  1m

frontend https_in
    bind *:${PORT} ssl crt ${CERT} crt ${KEY}
    default_backend http_back

backend http_back
    server web1 127.0.0.1:80
EOF
fi

exec /usr/sbin/haproxy -f "${HAP_CFG}" -db