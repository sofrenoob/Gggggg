// Inicializar carrossel
$(document).ready(function() {
    $('#bannerCarousel').carousel({
        interval: 5000 // Muda o slide a cada 5 segundos
    });
});

// Confirmar ações de remoção
function confirmDelete(message) {
    return confirm(message || 'Tem certeza que deseja remover este item?');
}

// Animação suave para rolagem
$('a.nav-link').on('click', function(event) {
    if (this.hash !== '') {
        event.preventDefault();
        const hash = this.hash;
        $('html, body').animate({
            scrollTop: $(hash).offset().top
        }, 800);
    }
});

// Exibir mensagens de erro ou sucesso (se houver)
document.addEventListener('DOMContentLoaded', function() {
    const errorMessage = '{{ error if error else "" }}';
    if (errorMessage) {
        alert(errorMessage);
    }
});