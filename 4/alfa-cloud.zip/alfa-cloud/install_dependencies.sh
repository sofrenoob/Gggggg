#!/bin/bash

echo "=== ALFA CLOUD - INSTALAÇÃO COMPLETA DO SERVIDOR VPN ==="

# Atualiza pacotes
apt update && apt upgrade -y

# Instala dependências
apt install -y python3 python3-pip stunnel4 shadowsocks-libev dante-server openssl net-tools unzip curl git build-essential screen

# Instala websocket
pip3 install websockets

# Cria diretórios
mkdir -p /etc/stunnel
mkdir -p /var/log
mkdir -p /etc/shadowsocks
mkdir -p /etc/systemd/system
mkdir -p /etc/slowdns
mkdir -p /opt/alfa-cloud/backend/scripts

# Gera certificados SSL para stunnel
openssl req -new -x509 -days 365 -nodes \
    -out /etc/stunnel/stunnel.pem \
    -keyout /etc/stunnel/stunnel.key \
    -subj "/C=BR/ST=SP/L=SP/O=AlfaCloud/OU=VPN/CN=alfacloud.local"

# Cria arquivo stunnel.conf
cat > /etc/stunnel/stunnel.conf <<EOF
cert = /etc/stunnel/stunnel.pem
key = /etc/stunnel/stunnel.key
pid = /var/run/stunnel.pid
output = /var/log/stunnel.log
client = no
[https]
accept = 443
connect = 127.0.0.1:22
EOF

# Cria shadowsocks.json
cat > /etc/shadowsocks.json <<EOF
{
  "server": "0.0.0.0",
  "server_port": 8388,
  "local_port": 1080,
  "password": "senha-secreta",
  "timeout": 300,
  "method": "aes-256-cfb"
}
EOF

# Cria sockd.conf
cat > /etc/sockd.conf <<EOF
logoutput: /var/log/sockd.log
internal: 0.0.0.0 port = 1080
external: eth0
clientmethod: none
socksmethod: none
user.notprivileged: nobody

client pass {
    from: 0.0.0.0/0 to: 0.0.0.0/0
    log: connect disconnect error
}

socks pass {
    from: 0.0.0.0/0 to: 0.0.0.0/0
    log: connect disconnect error
}
EOF

# Cria websocket.py
cat > /opt/alfa-cloud/backend/scripts/websocket.py <<EOF
import asyncio
import websockets

async def handler(websocket, path):
    while True:
        data = await websocket.recv()
        print(f"Recebido: {data}")
        await websocket.send("Conexão WebSocket ativa")

start_server = websockets.serve(handler, "0.0.0.0", 80)

asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()
EOF

# Permissões de execução
chmod +x /opt/alfa-cloud/backend/scripts/*.py

# Cria services systemd
cat > /etc/systemd/system/stunnel.service <<EOF
[Unit]
Description=Stunnel VPN (SSL Proxy)
After=network.target

[Service]
ExecStart=/usr/bin/stunnel /etc/stunnel/stunnel.conf
Restart=always

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/shadowsocks.service <<EOF
[Unit]
Description=Shadowsocks Proxy
After=network.target

[Service]
ExecStart=/usr/bin/ss-server -c /etc/shadowsocks.json
Restart=always

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/sockd.service <<EOF
[Unit]
Description=Dante SOCKS Proxy
After=network.target

[Service]
ExecStart=/usr/sbin/sockd -f /etc/sockd.conf
Restart=always

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/websocket.service <<EOF
[Unit]
Description=WebSocket Proxy Server
After=network.target

[Service]
ExecStart=/usr/bin/python3 /opt/alfa-cloud/backend/scripts/websocket.py
Restart=always

[Install]
WantedBy=multi-user.target
EOF

# Ativa e inicia os serviços
systemctl daemon-reexec
systemctl daemon-reload
systemctl enable stunnel.service
systemctl enable shadowsocks.service
systemctl enable sockd.service
systemctl enable websocket.service

systemctl start stunnel.service
systemctl start shadowsocks.service
systemctl start sockd.service
systemctl start websocket.service

echo "=== Instalação finalizada com sucesso! ==="
